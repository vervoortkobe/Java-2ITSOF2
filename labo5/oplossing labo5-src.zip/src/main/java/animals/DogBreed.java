package animals;

public enum DogBreed {
    LABRADOR_RETRIEVER, BULLDOG, POODLE, BEAGLE, GERMAN_SHEPHERD
}
