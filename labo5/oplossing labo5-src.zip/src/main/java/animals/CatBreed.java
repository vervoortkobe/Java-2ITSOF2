package animals;

public enum CatBreed {
    PERSIAN, RAGDOLL, BENGAL, SIAMESE, SPHYNX
}
