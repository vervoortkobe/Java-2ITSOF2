package shelter;

public class DuplicateAnimalException extends Exception {
}
