package shelter;

import animals.Animal;
import animals.Cat;
import animals.Dog;

import java.util.ArrayList;
import java.util.List;

public class AnimalShelter {
    private final List<Animal> animals = new ArrayList<>();

    public void addCat(Cat cat) throws DuplicateAnimalException {
        for (Animal animal : animals) {
            if(animal instanceof Cat) {
                Cat existing = (Cat) animal;
                if(existing.equals(cat)) {
                    throw new DuplicateAnimalException();
                }
            }
        }
        animals.add(cat);
    }
    
    public void addDog(Dog dog) throws DuplicateAnimalException {
        for (Animal animal : animals) {
            if(animal instanceof Dog) {
                Dog existing = (Dog) animal;
                if(existing.equals(dog)) {
                    throw new DuplicateAnimalException();
                }
            }
        }
        animals.add(dog);
    }

    public void printAllAnimals() {
        for (int i = 0; i < animals.size(); i++) {
            System.out.println(i + " " + animals.get(i).toString());
        }
    }

    public void showAnimal(int index) {
        try {
            System.out.println(animals.get(index).toString());
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Er is geen dier met index " + index);
        }
    }

    public void removeAnimal(int index) {
        try {
            animals.remove(index);
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Er is geen dier met index " + index);
        }
    }
}
