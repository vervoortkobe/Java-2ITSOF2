package agenda;

public class NoAgendaForDateException extends Exception {
    public NoAgendaForDateException(String message) {
        super(message);
    }
}
