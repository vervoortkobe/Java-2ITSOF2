package agenda;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class WeekAgenda {
    private final Map<LocalDate, Agenda> agendas = new HashMap<>();

    public void addWorkingDay(LocalDate date) {
        agendas.put(date, new Agenda());
    }

    public void addAppointment(LocalDate date, Appointment appointment) throws DateInPastException {
        if(date.isBefore(LocalDate.now())) {
            throw new DateInPastException("De datum " + date + " ligt in het verleden.");
        }
        agendas.get(date).addAppointment(appointment);
    }

    public void showNextAppointment(LocalDate date) throws NoAgendaForDateException {
        if(agendas.containsKey(date)) {
            throw new NoAgendaForDateException("Er bestaat geen agenda voor datum " + date);
        } else {
            agendas.get(date).showNextAppointment();
        }
    }
}
