package agenda;

public class DateInPastException extends Exception {
    public DateInPastException(String message) {
        super(message);
    }
}
