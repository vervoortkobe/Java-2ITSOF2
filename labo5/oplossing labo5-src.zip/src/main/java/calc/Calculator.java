package calc;

public class Calculator {

    public void printIterativeFibonacci(int target) {
        for (int i = 0; i < target; i++) {
            System.out.println(iterFibonacci(i));
        }
    }

    private int iterFibonacci(int count) {
        if (count <= 1) {
            return count;
        }
        int fib = 1;
        int previousFib = 1;

        for (int i = 2; i < count; i++) {
            int tmp = fib;
            fib = previousFib + fib;
            previousFib = tmp;
        }
        return fib;
    }

    public void printRecursiveFibonacci(int target) {
        printRecursiveFibonacci(0, target);
    }

    private void printRecursiveFibonacci(int counter, int target) {
        System.out.println(recFibonacci(counter));
        counter = counter + 1;
        if (counter < target) {
            printRecursiveFibonacci(counter, target);
        }
    }

    private int recFibonacci(int count) {
        if (count <= 1) {
            return count;
        } else {
            return recFibonacci(count - 1) + recFibonacci(count - 2);
        }
    }
}
