package calc;

public class Main {

    public static void main(String[] args) {
        Calculator calc = new Calculator();
        calc.printIterativeFibonacci(10);
        System.out.println("*****************************");
        calc.printRecursiveFibonacci(10);
    }
}
