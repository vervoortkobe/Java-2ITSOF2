package stacktrace;

public class BugThree {
    public void generateBug() {
        call1();
    }

    private void call1() {
        call2();
    }

    private void call2() {
        call3();
    }

    private void call3() {
        call4();
    }

    private void call4() {
        BugThreeHelper helper = new BugThreeHelper();
        helper.help(null);
    }

    private class BugThreeHelper {

        public void help(String test) {
            System.out.println(test.length());
        }
    }
}


