package stacktrace;

import java.time.LocalDate;

public class BugFour {
    public void generateBug() {
        LocalDate date = LocalDate.of(2200, null, 1);
    }
}
