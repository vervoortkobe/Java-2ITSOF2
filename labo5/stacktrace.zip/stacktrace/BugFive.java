package stacktrace;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

public class BugFive {
    public void generateBug() {
        Socket socket = new Socket();
        try {
            socket.connect(new InetSocketAddress("127.0.0.1", 2000));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
