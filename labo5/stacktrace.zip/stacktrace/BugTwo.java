package stacktrace;

public class BugTwo {
    public void generateBug() {
        int first = 10;
        int second = 2;
        divide(first, second);
    }

    private void divide(int first, int second) {
        second = 0;
        double result = first / second;
    }
}
