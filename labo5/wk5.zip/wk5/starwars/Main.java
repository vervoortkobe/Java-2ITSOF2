package be.ap.wk5.starwars;

import be.ap.wk5.starwars.characters.DarthVader;
import be.ap.wk5.starwars.characters.HanSolo;
import be.ap.wk5.starwars.characters.LukeSkywalker;
import be.ap.wk5.starwars.characters.StarWarsFatherException;

public class Main {
    public static void main(String[] args) {
        DarthVader vader = new DarthVader();
        try {
            System.out.println(vader.isFather(new LukeSkywalker()));
            System.out.println(vader.isFather(new HanSolo()));
            System.out.println(vader.isFather(new DarthVader()));
        } catch (StarWarsFatherException e) {
            e.printStackTrace();
            System.out.println(e.getMessage() + " " + e.getName());
            //System.out.println("Je kan niet je eigen vader zijn.");
        }
    }
}
