package be.ap.wk5.starwars.characters;

public enum Colour {
    RED, GREEN, BLUE
}
