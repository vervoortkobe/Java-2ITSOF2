package be.ap.wk5;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        List<String> names = new ArrayList<>();
        //names.get(0);


        DecimalFormat format = new DecimalFormat("00.00");

        try {
            double value = format.parse("12").doubleValue();
            Class.forName("DemoClass");
            System.out.println(value);
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            System.out.println("Dit wordt altijd uitgevoerd");
        }

    }
}
