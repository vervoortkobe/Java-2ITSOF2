package be.ap.wk5.stacktrace;

public class Main {

    public static void main(String[] args) {
        BugOne bugOne = new BugOne();
        //bugOne.generateBug();

        BugTwo bugTwo = new BugTwo();
        //bugTwo.generateBug();

        BugThree bugThree = new BugThree();
        //bugThree.generateBug();

        BugFour bugFour = new BugFour();
        //bugFour.generateBug();

        BugFive bugFive = new BugFive();
        bugFive.generateBug();
    }
}
