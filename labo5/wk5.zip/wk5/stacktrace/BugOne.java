package be.ap.wk5.stacktrace;

import java.util.ArrayList;
import java.util.List;

public class BugOne {
    public void generateBug() {
        List<String> list = new ArrayList<>();
        System.out.println(list.get(0));
    }
}
