package party;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import animals.Animal;

public class Party {
    private final List<Animal> animals = new ArrayList<>();

    public void addToParty(Animal animal) {
        animals.add(animal);
    }

    public void eatCake(int pieces) {
        animals.sort(new EatCakeComparator());
        int index = 0;
        while (pieces > 0) {
            System.out.println(animals.get(index).getName() + " eet een stuk taart.");
            index++;
            if (index == animals.size()) {
                index = 0;
            }
            pieces--;
        }
        for (int i = index; i < animals.size(); i++) {
            System.out.println(animals.get(i).getName() + " krijgt geen taart.");
        }
    }

    public void singBirthdaySong() {
        List<Animal> singing = new ArrayList<>();
        for (Animal animal : animals) {
            if (!animal.getName().equals("Hermien")) {
                singing.add(animal);
            }
        }
        List<Animal> madeSound = new ArrayList<>();
        int count = 12; //aantal lettergrepen
        while (count > 0) {
            Animal animal = pickRandomAnimal(singing);
            while (madeSound.contains(animal)) {
                animal = pickRandomAnimal(singing);
            }
            animal.makeSound();
            madeSound.add(animal);
            if (madeSound.size() == singing.size()) {
                madeSound.clear();
            }
            count--;
        }
    }

    private Animal pickRandomAnimal(List<Animal> singing) {
        Random random = new Random();
        int index = random.nextInt(singing.size());
        return singing.get(index);
    }
}
