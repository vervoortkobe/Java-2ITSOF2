package party;

import java.util.Comparator;

import animals.Animal;

public class EatCakeComparator implements Comparator<Animal> {
    @Override
    public int compare(Animal o1, Animal o2) {
        if(o1.getName().equals("Hermien")) {
            return -1;
        } else if (o2.getName().equals("Hermien")) {
            return 1;
        }
        return o1.getDateOfBirth().compareTo(o2.getDateOfBirth());
    }
}
