package party;

import java.time.LocalDate;

import animals.Cat;
import animals.CatBreed;
import animals.Dog;
import animals.DogBreed;
import animals.Gender;
import animals.Hippo;
import animals.Lion;
import animals.Monkey;

public class Main {

    public static void main(String[] args) {
        Party party = new Party();
        party.addToParty(new Hippo("Hermien", Gender.FEMALE, LocalDate.of(1980, 10, 10)));
        party.addToParty(new Cat("Pluisje", CatBreed.PERSIAN, Gender.FEMALE, LocalDate.of(2014, 5, 26)));
        party.addToParty(new Dog("Brutus", DogBreed.BULLDOG, Gender.MALE, LocalDate.of(2016, 8, 15)));
        party.addToParty(new Lion("Simba", Gender.MALE, LocalDate.of(2018, 5, 5)));
        party.addToParty(new Monkey("Choco", Gender.MALE, LocalDate.of(2012, 1, 18)));

        party.eatCake(8);
        System.out.println("*********************");
        party.eatCake(12);
        System.out.println("*********************");
        party.singBirthdaySong();
    }
}
