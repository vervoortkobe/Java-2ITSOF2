package be.ap.wk3.starwars.movies;

import java.util.Objects;

public class StarWarsMovie implements Comparable<StarWarsMovie> {
    private final int episode;
    private final String title;

    public StarWarsMovie(int episode, String title) {
        this.episode = episode;
        this.title = title;
    }

    public int getEpisode() {
        return episode;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public String toString() {
        return "StarWarsMovie{" +
                "episode=" + episode +
                ", title='" + title + '\'' +
                '}';
    }

    @Override
    public int compareTo(StarWarsMovie o) {
        return Integer.compare(this.episode, o.episode);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StarWarsMovie that = (StarWarsMovie) o;
        return episode == that.episode && Objects.equals(title, that.title);
    }

    @Override
    public int hashCode() {
        return Objects.hash(episode, title);
    }
}
