package be.ap.wk3.starwars.character;

public enum Side {
    DARK, LIGHT
}
