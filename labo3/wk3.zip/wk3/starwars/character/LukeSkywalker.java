package be.ap.wk3.starwars.character;

public class LukeSkywalker extends StarWarsCharacter {
    private Side side = Side.LIGHT;

    public LukeSkywalker() {
        super(true);
    }

    public Side getSide() {
        return side;
    }

    public String favoriteFightingStyle() {
        return "jump";
    }
}
