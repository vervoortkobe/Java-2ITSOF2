package be.ap.wk3.starwars;

import be.ap.wk3.starwars.character.DarthVader;
import be.ap.wk3.starwars.character.LukeSkywalker;
import be.ap.wk3.starwars.character.StarWarsCharacter;
import be.ap.wk3.starwars.movies.SortByName;
import be.ap.wk3.starwars.movies.StarWarsMovie;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        StarWarsMovie episode1 = new StarWarsMovie(1, "The Phantom Menace");
        StarWarsMovie episode2 = new StarWarsMovie(2, "Attack of the Clones");
        StarWarsMovie episode3 = new StarWarsMovie(3, "Revenge of the Sith");
        StarWarsMovie episode4 = new StarWarsMovie(4, "A New Hope");
        StarWarsMovie episode5 = new StarWarsMovie(5, "The Empire Strikes Back");
        StarWarsMovie episode6 = new StarWarsMovie(6, "Return of the Jedi");


        Queue<StarWarsMovie> movieQueue = new PriorityQueue<>(new SortByName());
        movieQueue.offer(episode2);
        movieQueue.offer(episode1);

        //System.out.println(movieQueue.poll());


        SortedSet<StarWarsMovie> movieSet = new TreeSet<>(new SortByName());
        movieSet.add(episode2);
        movieSet.add(episode1);
        movieSet.add(episode3);
        movieSet.add(new StarWarsMovie(1, "The Phantom Menace"));

        for (StarWarsMovie starWarsMovie : movieSet) {
            System.out.println(starWarsMovie);
        }
        System.out.println("--------");
        System.out.println(movieSet.first());
        System.out.println(movieSet.last());

        System.out.println("--------");

        SortedMap<StarWarsMovie, StarWarsCharacter> movieCharacters = new TreeMap<>(new SortByName());

        movieCharacters.put(episode5, new DarthVader());
        movieCharacters.put(episode4, new LukeSkywalker());


        System.out.println(movieCharacters.get(episode4));
        System.out.println(movieCharacters.get(episode5));

        for (StarWarsMovie starWarsMovie : movieCharacters.keySet()) {
            System.out.println(starWarsMovie);
        }

        for (StarWarsCharacter value : movieCharacters.values()) {
            System.out.println(value);
        }

        System.out.println("--------");

        System.out.println(movieCharacters.get(movieCharacters.firstKey()));
        System.out.println(movieCharacters.get(movieCharacters.lastKey()));


        System.out.println("--------");

        Map<StarWarsMovie, List<StarWarsCharacter>> movieListMap = new HashMap<>();

        movieListMap.put(episode4, new ArrayList<>());
        movieListMap.get(episode4).add(new LukeSkywalker());
        movieListMap.get(episode4).add(new DarthVader());

        for(StarWarsCharacter character : movieListMap.get(episode4)) {
            System.out.println(character);
        }


        System.out.println("--------");

        Scanner scanner = new Scanner(System.in);
        System.out.println("Geef je naam in:");
        String name = scanner.nextLine();
        System.out.println("Hallo " + name);
        System.out.println("Geef je leeftijd in:");
        int age = scanner.nextInt();
        scanner.nextLine(); //enter opvangen !!
        System.out.println("Je bent " + age + " jaar jong.");
        System.out.println("dit is een test");
        String test = scanner.nextLine();
        System.out.println("Test '" + test + "'");

        int choice = 0;
        while(choice != 5) {
            System.out.println("Maak uw keuze uit volgende opties:");
            System.out.println("1. optie 1");
            System.out.println("2. optie 2");
            System.out.println("3. optie 3");
            System.out.println("4. optie 4");
            System.out.println("5. beëindignen");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("doe iets");
                    break;
            }

        }

    }
}
