package patient;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;
import java.util.Optional;

public class PatientDAO {

    public List<Patient> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT p FROM Patient p", Patient.class).list();
        }
    }

    public Optional<Patient> findById(Integer id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Patient patient = session.get(Patient.class, id);
            if(patient == null) {
                return Optional.empty();
            } else {
                //force fetch the cards
                patient.getCards().size();
                return Optional.of(patient);
            }
        }
    }

    public void create(Patient patient) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.persist(patient);

            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
        }
    }

    public void update(Patient patient) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.merge(patient);

            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
        }
    }
}
