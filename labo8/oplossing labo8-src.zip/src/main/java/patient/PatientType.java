package patient;

public enum PatientType {
    CAT, DOG
}
