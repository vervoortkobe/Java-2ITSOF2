package patient;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "CARD")
public class Card {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    @Column(name = "date")
    private LocalDate date;
    @Column(name = "reason")
    private String reason;
    @Column(name = "treatment")
    private String treatment;

    public Card() {
    }

    public Card(LocalDate date, String reason, String treatment) {
        this.date = date;
        this.reason = reason;
        this.treatment = treatment;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    @Override
    public String toString() {
        return "Card{" +
                "id=" + id +
                ", date=" + date +
                ", reason='" + reason + '\'' +
                ", treatment='" + treatment + '\'' +
                '}';
    }
}
