package patient;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;
import java.util.Optional;

public class CardDAO {

    public void create(Card card) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.persist(card);

            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
        }
    }
}
