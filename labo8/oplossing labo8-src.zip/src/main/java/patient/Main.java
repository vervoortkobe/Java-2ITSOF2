package patient;

import jakarta.transaction.Transactional;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        PatientDAO patientDAO = new PatientDAO();
        CardDAO cardDAO = new CardDAO();

        File input = new File("src/main/resources/patienten.txt");

        try {
            Files.lines(input.toPath())
                    .skip(1)
                    .map(line -> stringToPatient(line))
                    .forEach(p -> patientDAO.create(p));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        System.out.println("Welkom gebruiker");
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        while (choice != 4) {
            System.out.println("Maak je keuze uit volgende opties");
            System.out.println("1 : toon alle patiënten");
            System.out.println("2 : toon ziektefiches voor patiënt");
            System.out.println("3 : voeg ziektefiche voor patiënt toe");
            System.out.println("4 : einde");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    List<Patient> patients = patientDAO.findAll();
                    for (Patient patient : patients) {
                        System.out.println(patient);
                    }
                    break;
                case 2:
                    showCards(scanner, patientDAO);
                    break;
                case 3:
                    createCard(scanner, patientDAO, cardDAO);
                    break;
                default:
                    choice = 4;
                    break;
            }
        }
    }

    private static void showCards(Scanner scanner, PatientDAO dao) {
        System.out.println("Geef de index van de patiënt:");
        int id = scanner.nextInt();
        scanner.nextLine();
        Optional<Patient> patient = dao.findById(id);
        patient.ifPresentOrElse(
                p -> System.out.println(p.getCards()),
                () -> System.out.println("Geen patiënt met id " + id + " gevonden")
        );
    }

    @Transactional
    private static void createCard(Scanner scanner, PatientDAO patientDAO, CardDAO cardDAO) {
        System.out.println("Maak nieuwe ziektefiche aan");
        System.out.println("Geef de index van de patiënt:");
        int id = scanner.nextInt();
        scanner.nextLine();
        Optional<Patient> patient = patientDAO.findById(id);
        if(patient.isPresent()) {
            Patient thePatient = patient.get();
            //FIXME add input for date, reason and treatment
            Card card = new Card(LocalDate.now(), "test", "test");
            cardDAO.create(card);
            thePatient.getCards().add(card);
            patientDAO.update(thePatient);
        } else {
            System.out.println("Geen patiënt met id " + id + " gevonden");
        }
    }

    private static Patient stringToPatient(String line) {
        String[] split = line.split(",");
        return new Patient(split[0], PatientType.valueOf(split[1]));
    }
}