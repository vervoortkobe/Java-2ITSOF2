package bank;

public class Account {

    private final String accountNumber;
    private int total;

    public Account(String accountNumber) {
        this.accountNumber = accountNumber;
        this.total = 100;
    }

    public synchronized void withdraw(String name, int withdrawal) {
        if (total >= withdrawal) {
            System.out.println(name + " withdrawn " + withdrawal);
            total = total - withdrawal;
            System.out.println("Balance after withdrawal: " + total);
        } else {
            System.out.println(name + " cannot withdraw " + withdrawal);

            System.out.println("Your balance remains: " + total);
        }
        // 1 seconde wachten na iedere actie
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public synchronized void deposit(String name, int deposit) {
        System.out.println(name + " deposited " + deposit);
        total = total + deposit;
        System.out.println("Balance after deposit: " + total);
        // 1 seconde wachten na iedere actie
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public int getBalance() {
        return total;
    }
}