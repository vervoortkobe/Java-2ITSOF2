package bank;

public class ThreadWithdraw extends Thread {

    private final Account account;
    private final String user;
    private final int amount;

    public ThreadWithdraw(Account account, String user, int amount) {
        this.account = account;
        this.user = user;
        this.amount = amount;
    }

    @Override
    public void run() {
        account.withdraw(user, amount);
    }
}
