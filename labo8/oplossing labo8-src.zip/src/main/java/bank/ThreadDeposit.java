package bank;

public class ThreadDeposit extends Thread {

    private final Account account;
    private final String user;
    private final int amount;

    public ThreadDeposit(Account account, String user, int amount) {
        this.account = account;
        this.user = user;
        this.amount = amount;
    }

    @Override
    public void run() {
        account.deposit(user, amount);
    }
}
