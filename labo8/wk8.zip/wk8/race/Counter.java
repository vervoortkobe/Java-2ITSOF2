package be.ap.wk8.race;

/**
 * Dit is de counter class die 1 optelt bij een getal.
 */
public class Counter implements Runnable {

    private int shared = 0;

    @Override
    public void run() {
        synchronized (this) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            shared++;
            System.out.println("Value on thread " + Thread.currentThread().getName() + " after increment " + shared);
        }
    }
}
