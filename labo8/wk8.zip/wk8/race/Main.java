package be.ap.wk8.race;

public class Main {

    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {
            Counter counter = new Counter();
            Thread t1 = new Thread(counter, "T1");
            Thread t2 = new Thread(counter, "T2");
            t1.start();
            t2.start();
            while (t1.isAlive() || t2.isAlive()) {
                //wait
            }
            System.out.println("*****");
        }

    }
}
