package be.ap.wk8.threading;

import java.util.List;

/**
 * Dit is de doubler class
 * <h1>We steken er ook nog html</h1>
 * <a href="https://www.google.be">link naar google</a>
 *
 * @author Jeroen De Vos
 * @version 1.0
 */
public class Doubler extends Thread {
    private final List<Integer> list;


    /**
     * @param list 
     */
    public Doubler(List<Integer> list) {
        this.list = list;
    }

    public void execute() {
        for (int i = 0; i < list.size(); i++) {
            if(!isInterrupted()) {
                list.set(i, list.get(i) * 2);
            }
        }
    }

    @Override
    public void run() {

            execute();


    }
}
