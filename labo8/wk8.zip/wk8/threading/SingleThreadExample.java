package be.ap.wk8.threading;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SingleThreadExample {

    public void execute() {
        //init list with integers 1 -> 400
        List<Integer> list = new ArrayList<>();
        for (int i = 1; i <= 400; i++) {
            list.add(i);
        }
        runInSingleThread(list);
    }

    private void runInSingleThread(List<Integer> list) {
        LocalDateTime start = LocalDateTime.now();

        Doubler doubler = new Doubler(list);
        doubler.execute();

        LocalDateTime end = LocalDateTime.now();
        System.out.println(list);
        Duration d = Duration.between(start, end);
        System.out.println(d.getNano() + " nano seconds");
    }
}
