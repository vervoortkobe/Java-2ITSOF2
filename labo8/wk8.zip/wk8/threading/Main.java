package be.ap.wk8.threading;

public class Main {

    public static void main(String[] args) {

        SingleThreadExample example1 = new SingleThreadExample();
        example1.execute();

        MultiThreadExample example2 = new MultiThreadExample();
        example2.execute();

    }
}


