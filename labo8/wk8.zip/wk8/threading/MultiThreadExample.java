package be.ap.wk8.threading;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class MultiThreadExample {

    public void execute() {
        List<Integer> list1 = new ArrayList<>();
        for (int i = 1; i <= 200; i++) {
            list1.add(i);
        }
        List<Integer> list2 = new ArrayList<>();
        for (int i = 201; i <= 400; i++) {
            list2.add(i);
        }
        runInMultiThread(list1, list2);
    }

    private void runInMultiThread(List<Integer> list1, List<Integer> list2) {
        LocalDateTime start = LocalDateTime.now();

        Thread t1 = new Thread(new Doubler(list1), "Thread1");
        Thread t2 = new Thread(new Doubler(list2), "Thread2");
        t1.start();
        t2.start();

        t1.interrupt();

        while(t1.isAlive() || t2.isAlive()) {
            //effe nog bezig
        }

        LocalDateTime end = LocalDateTime.now();
        System.out.println(list1);
        System.out.println(list2);
        Duration d = Duration.between(start, end);
        System.out.println(d.getNano() + " nano seconds");
    }
}
