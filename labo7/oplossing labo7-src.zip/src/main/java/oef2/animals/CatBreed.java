package oef2.animals;

public enum CatBreed {
    PERSIAN, RAGDOLL, BENGAL, SIAMESE, SPHYNX
}
