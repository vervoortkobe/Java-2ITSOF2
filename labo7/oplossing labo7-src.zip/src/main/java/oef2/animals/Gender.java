package oef2.animals;

public enum Gender {
    MALE, MALE_NEUTERED, FEMALE, FEMALE_NEUTERED
}
