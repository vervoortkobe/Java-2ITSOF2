package oef2.animals;

public interface DomesticatedAnimal {
}
