package oef2.dao;

import oef2.animals.Animal;
import oef2.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;
import java.util.Optional;

public class AnimalDAO {

    public List<Animal> findAllAnimals() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT a FROM Animal a", Animal.class).list();
        }
    }

    public Optional<Animal> findById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return Optional.ofNullable(session.get(Animal.class, id));
        }
    }

    public void deleteAnimal(Animal animal) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.remove(animal);

            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
        }
    }
}
