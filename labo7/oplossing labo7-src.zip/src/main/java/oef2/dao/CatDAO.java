package oef2.dao;

import oef2.animals.Cat;
import oef2.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CatDAO {

    public void createCat(Cat cat) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.persist(cat);

            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
        }
    }
}
