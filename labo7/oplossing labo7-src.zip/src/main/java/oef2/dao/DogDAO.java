package oef2.dao;

import oef2.animals.Dog;
import oef2.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class DogDAO {

    public void createDog(Dog dog) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.persist(dog);

            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
        }
    }
}
