package oef2.util;

import oef2.animals.Animal;
import oef2.animals.Cat;
import oef2.animals.Dog;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
    private static SessionFactory sessionFactory;

    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            Configuration configuration = new Configuration();
            configuration.configure("hibernate-oef2.cfg.xml");
            configuration.addAnnotatedClass(Animal.class);
            configuration.addAnnotatedClass(Cat.class);
            configuration.addAnnotatedClass(Dog.class);

            sessionFactory = configuration.buildSessionFactory();
        }

        return sessionFactory;
    }
}
