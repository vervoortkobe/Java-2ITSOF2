package oef2.shelter;

public class DuplicateAnimalException extends Exception {
}
