package oef1;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class BreedDAO {

    public void createBreed(Breed breed) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.persist(breed);

            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
        }
    }

    public List<Breed> findAllBreeds() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT b FROM Breed b", Breed.class).list();
        }
    }

    public List<String> findAllNamesBreeds() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT b.name FROM Breed b", String.class).list();
        }
    }

    public List<Breed> findBreedsContainingDog() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT b FROM Breed b WHERE upper(b.name) LIKE '%DOG%'", Breed.class).list();
        }
    }

    public List<Breed> findBreedsMaleBetween(int lower, int upper) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT b FROM Breed b WHERE b.weightMale > " + lower + " AND b.weightMale < " + upper, Breed.class).list();
        }
    }

    public Long countBreedsShepherd() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT COUNT(b) FROM Breed b WHERE upper(b.name) LIKE '%HERDER%'", Long.class).getSingleResult();
        }
    }
}
