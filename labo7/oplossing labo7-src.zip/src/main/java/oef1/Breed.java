package oef1;

import jakarta.persistence.*;

@Entity
@Table(name = "BREED")
public class Breed {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "name")
    private String name;
    @Column(name = "weight_male")
    private Double weightMale;
    @Column(name = "weight_female")
    private Double weightFemale;
    @Column(name = "average_age")
    private String averageAge;

    public Breed() {

    }

    public Breed(String name, Double weightMale, Double weightFemale, String averageAge) {
        this.name = name;
        this.weightMale = weightMale;
        this.weightFemale = weightFemale;
        this.averageAge = averageAge;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getWeightMale() {
        return weightMale;
    }

    public void setWeightMale(Double weightMale) {
        this.weightMale = weightMale;
    }

    public Double getWeightFemale() {
        return weightFemale;
    }

    public void setWeightFemale(Double weightFemale) {
        this.weightFemale = weightFemale;
    }

    public String getAverageAge() {
        return averageAge;
    }

    public void setAverageAge(String averageAge) {
        this.averageAge = averageAge;
    }

    @Override
    public String toString() {
        return "Breed{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", weightMale=" + weightMale +
                ", weightFemale=" + weightFemale +
                ", averageAge='" + averageAge + '\'' +
                '}' + "\n";
    }
}
