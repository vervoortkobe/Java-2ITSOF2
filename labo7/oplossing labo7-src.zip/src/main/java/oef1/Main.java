package oef1;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class Main {

    public static void main(String[] args) {

        BreedDAO dao = new BreedDAO();

        File input = new File("src/main/resources/honden.csv");

        try {
            Files.lines(input.toPath())
                    .skip(1)
                    .map(line -> stringToBreed(line))
                    .forEach(breed -> dao.createBreed(breed));
        } catch (IOException e) {
            e.printStackTrace();
        }

        //option 1 : query on the database
        System.out.println(dao.findBreedsContainingDog());

        //option 2 : use streams
        dao.findAllBreeds().stream()
                .filter(breed -> breed.getName().toLowerCase().contains("dog"))
                .forEach(breed -> System.out.println(breed.getName()));

        //option 1 : query on the database
        System.out.println(dao.findBreedsMaleBetween(50, 70));

        //option 2 : use streams
        dao.findAllBreeds().stream()
                .filter(breed -> breed.getWeightMale() > 50 && breed.getWeightMale() < 70)
                .forEach(breed -> System.out.println(breed.getName()));

        //option 1 : query on the database
        System.out.println(dao.countBreedsShepherd());

        //option 2 : use streams
        long count = dao.findAllBreeds().stream()
                .filter(breed -> breed.getName().toLowerCase().contains("herder"))
                .count();

        System.out.println(count);
    }

    private static Breed stringToBreed(String line) {
        String[] split = line.split(",");
        return new Breed(split[0], Double.valueOf(split[1]), Double.valueOf(split[2]), split[3]);
    }
}
