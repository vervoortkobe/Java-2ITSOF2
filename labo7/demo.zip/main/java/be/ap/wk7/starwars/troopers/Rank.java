package be.ap.wk7.starwars.troopers;

public enum Rank {
    TROOPER, SERGEANT
}
