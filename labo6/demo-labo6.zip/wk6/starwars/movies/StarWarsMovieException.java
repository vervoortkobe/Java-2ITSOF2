package be.ap.wk6.starwars.movies;

public class StarWarsMovieException extends Exception {
}
