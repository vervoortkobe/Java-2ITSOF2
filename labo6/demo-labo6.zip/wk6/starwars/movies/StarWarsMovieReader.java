package be.ap.wk6.starwars.movies;

import be.ap.wk6.starwars.characters.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StarWarsMovieReader implements AutoCloseable {
    private final List<StarWarsMovie> movies = new ArrayList<>();
    private int index;

    public StarWarsMovieReader() {
        initialize();
        index = 0;
    }

    private void initialize() {
        movies.add(new StarWarsMovie(1, "The Phantom Menace", LocalDate.of(1999, 1, 1),
                Arrays.asList(new ObiwanKenobi(), new AnakinSkywalker())));
        movies.add(new StarWarsMovie(2, "Attack of the Clones", LocalDate.of(2002, 1, 1),
                Arrays.asList(new ObiwanKenobi(), new AnakinSkywalker())));
        movies.add(new StarWarsMovie(3, "Revenge of the Sith", LocalDate.of(2005, 1, 1),
                Arrays.asList(new ObiwanKenobi(), new AnakinSkywalker(), new DarthVader())));
        movies.add(new StarWarsMovie(4, "A New Hope", LocalDate.of(1977, 1, 1),
                Arrays.asList(new ObiwanKenobi(), new LukeSkywalker(), new DarthVader(), new HanSolo())));
        movies.add(new StarWarsMovie(5, "The Empire Strikes Back", LocalDate.of(1980, 1, 1),
                Arrays.asList(new LukeSkywalker(), new DarthVader(), new HanSolo(), new GeneralVeers())));
        movies.add(new StarWarsMovie(6, "Return of the Jedi", LocalDate.of(1983, 1, 1),
                Arrays.asList(new LukeSkywalker(), new DarthVader(), new HanSolo(), new AnakinSkywalker())));
        movies.add(new StarWarsMovie(7, "The Force Awakens", LocalDate.of(2015, 1, 1),
                Arrays.asList(new HanSolo(), new Rey(), new KyloRen())));
        movies.add(new StarWarsMovie(8, "The Last Jedi", LocalDate.of(2017, 1, 1),
                Arrays.asList(new Rey(), new KyloRen(), new LukeSkywalker())));
        movies.add(new StarWarsMovie(9, "The Rise of Skywalker", LocalDate.of(2019, 1, 1),
                Arrays.asList(new Rey(), new KyloRen(), new LukeSkywalker())));
    }

    public boolean hasNext() {
        return index < movies.size();
    }

    public StarWarsMovie readMovie() throws StarWarsMovieException {
        if(hasNext()) {
            StarWarsMovie movie = movies.get(index);
            index++;
            return movie;
        } else {
            throw new StarWarsMovieException();
        }
    }

    @Override
    public void close() {
        System.out.println("close method executed");
        index = 0;
    }
}
