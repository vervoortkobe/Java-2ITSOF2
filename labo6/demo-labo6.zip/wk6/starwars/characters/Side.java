package be.ap.wk6.starwars.characters;

public enum Side {
    LIGHT, DARK
}
