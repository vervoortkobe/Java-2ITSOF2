package be.ap.wk6.starwars.characters;

public class StarWarsFatherException extends Exception {
    private final String name;

    public StarWarsFatherException(String message, String name) {
        super(message);
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
