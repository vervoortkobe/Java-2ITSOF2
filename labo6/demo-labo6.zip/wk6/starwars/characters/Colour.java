package be.ap.wk6.starwars.characters;

public enum Colour {
    RED, GREEN, BLUE
}
