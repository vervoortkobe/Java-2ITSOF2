package be.ap.wk6.starwars;

import be.ap.wk6.starwars.characters.Actor;
import be.ap.wk6.starwars.characters.AnakinSkywalker;
import be.ap.wk6.starwars.characters.HanSolo;
import be.ap.wk6.starwars.movies.StarWarsMovie;
import be.ap.wk6.starwars.movies.StarWarsMovieException;
import be.ap.wk6.starwars.movies.StarWarsMovieReader;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

    private static Logger logger = LogManager.getLogger();

    public static void main(String[] args) {

        /*
        File file = new File("demo.txt");

        System.out.println(file.exists());

        try {
            file.createNewFile();

            System.out.println(file.exists());

            System.out.println(file.isFile());

            file.delete();

            System.out.println(file.exists());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

         */

        /*
        File folder = new File("demo");

        System.out.println(folder.exists());

        folder.delete();

        System.out.println(folder.exists());

        folder.mkdir();

        System.out.println(folder.exists());

        File[] files = folder.listFiles();


         */
/*
        File movies = new File("src/main/resources/starwars/movies.txt");

        File output = new File("src/main/resources/starwars/output.txt");

        try {
            List<StarWarsMovie> starWarsMovies = Files.lines(movies.toPath())
                    .map(line -> createMovie(line))
                    .collect(Collectors.toList());


            List<String> lines = starWarsMovies.stream()
                            .map(movie -> movie.getTitle())
                            .collect(Collectors.toList());

            Files.write(output.toPath(), lines);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }*/

        StarWarsMovieReader reader1 = new StarWarsMovieReader();
        StarWarsMovieReader reader2 = new StarWarsMovieReader();

        try (reader1;reader2) {
            if(reader1.hasNext()) {
                System.out.println(reader1.readMovie());
            }
        } catch (StarWarsMovieException e) {
            throw new RuntimeException(e);
        }


        logger.log(Level.INFO, "Dit is mijn info bericht");

    }

    private static StarWarsMovie createMovie(String line) {
        //TODO data uit line halen
        String[] split = line.split(";");
        System.out.println(split[1]);

        StarWarsMovie movie = new StarWarsMovie(0, split[1], null, null);
        return movie;
    }
}
