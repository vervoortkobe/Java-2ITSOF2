package ownerpets;

public enum PetType {
}
