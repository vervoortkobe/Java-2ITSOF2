package ownerpets;

import java.time.LocalDate;

public class Pet {
    private final String name;
    private final LocalDate dateOfBirth;
    private final PetType type;

    public Pet(String name, LocalDate dateOfBirth, PetType type) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.type = type;
    }

    @Override
    public String toString() {
        return "Pet{" +
                "name='" + name + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                ", type=" + type +
                '}';
    }
}
