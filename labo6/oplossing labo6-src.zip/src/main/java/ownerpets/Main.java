package ownerpets;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
        File input = new File("src/main/resources/eigenaars.txt");

        try {
            //loop 1 : alle owners verzamelen
            List<Owner> owners = Files.lines(input.toPath())
                    .skip(1)
                    .map(line -> stringToOwner(line))
                    .distinct()
                    .collect(Collectors.toList());

            //loop 2 : per owner de huisdieren verzamelen
            for (Owner owner : owners) {
                Set<Pet> pets = Files.lines(input.toPath())
                        .skip(1)
                        .filter(line -> line.contains(owner.getFirstName() + ";" + owner.getLastName()))
                        .map(line -> stringToPet(line))
                        .collect(Collectors.toSet());
                owner.setPets(pets);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static Owner stringToOwner(String line) {
        String[] split = line.split(";");
        return new Owner(split[0], split[1]);
    }

    private static Pet stringToPet(String line) {
        String[] split = line.split(";");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        return new Pet(split[2], LocalDate.parse(split[3], formatter), PetType.valueOf(split[4]));
    }
}
