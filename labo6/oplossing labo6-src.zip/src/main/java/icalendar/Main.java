package icalendar;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<String> lines = new ArrayList<>();

        ZonedDateTime start = ZonedDateTime.now();
        ZonedDateTime end = ZonedDateTime.now();
        String event = "Test event";

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'");

        lines.add("BEGIN:VCALENDAR");
        lines.add("VERSION:2.0");
        lines.add("CALSCALE:GREGORIAN");
        lines.add("BEGIN:VEVENT");
        lines.add("DTSTART:" + start.format(formatter));
        lines.add("DTEND:" + end.format(formatter));
        lines.add("SUMMARY:" + event);
        lines.add("END:VEVENT");
        lines.add("END:VCALENDAR");

        File output = new File("src/main/resources/afspraak.ics");
        try {
            Files.write(output.toPath(), lines);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
