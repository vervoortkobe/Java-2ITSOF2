package shelter;

import animals.*;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        AnimalShelter shelter = new AnimalShelter();
        shelter.addCat(new Cat("Qianta", CatBreed.SIAMESE, Gender.FEMALE_NEUTERED, LocalDate.of(2023,3,15)));
        shelter.addDog(new Dog("Brutus", DogBreed.BULLDOG, Gender.MALE, LocalDate.of(2020, 5, 18)));
        shelter.addCat(new Cat("Pluisje", CatBreed.RAGDOLL, Gender.FEMALE, LocalDate.of(2018, 4, 5)));

        shelter.printAllAnimals();

        shelter.showAnimal(1);
        shelter.removeAnimal(1);
        shelter.printAllAnimals();
    }
}
