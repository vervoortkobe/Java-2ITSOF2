package zoo;

import java.util.Comparator;

public class IdComparator implements Comparator<Bonobo> {
    @Override
    public int compare(Bonobo o1, Bonobo o2) {
        return o2.getId() - o1.getId();
    }
}
