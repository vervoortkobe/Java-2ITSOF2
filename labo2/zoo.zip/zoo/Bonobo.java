package zoo;

public class Bonobo {
    private final int id;
    private final String name;
    private final int yearOfBirth;
    private final Gender gender;

    public Bonobo(int id, String name, int yearOfBirth, Gender gender) {
        this.id = id;
        this.name = name;
        this.yearOfBirth = yearOfBirth;
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Bonobo{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", yearOfBirth=" + yearOfBirth +
                ", gender=" + gender +
                '}';
    }
}
