package be.ap.wk2.starwars.trooper;

import java.util.Objects;

public class StormTrooper implements Comparable<StormTrooper> {
    private final String name;
    private final Rank rank;

    public StormTrooper(String name, Rank rank) {
        this.name = name;
        this.rank = rank;
    }

    public String getName() {
        return name;
    }

    public Rank getRank() {
        return rank;
    }

    @Override
    public String toString() {
        return "StormTrooper{" +
                "name='" + name + '\'' +
                ", rank=" + rank +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StormTrooper that = (StormTrooper) o;
        return Objects.equals(name, that.name) && rank == that.rank;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, rank);
    }

    @Override
    public int compareTo(StormTrooper o) {
        if(this.rank == Rank.SERGEANT) {
            return -1;
        } else if(o.getRank() == Rank.SERGEANT) {
            return 1;
        } else {
            return this.name.compareTo(o.name);
        }
    }
}
