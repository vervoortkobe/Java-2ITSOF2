package be.ap.wk2.starwars.trooper;

public enum Rank {
    SOLDIER, SERGEANT
}
