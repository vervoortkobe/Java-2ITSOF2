package be.ap.wk2.starwars.trooper;

import java.util.Comparator;

public class SortByNameComperator implements Comparator<StormTrooper> {
    @Override
    public int compare(StormTrooper o1, StormTrooper o2) {
        return o1.getName().compareTo(o2.getName());
    }
}
