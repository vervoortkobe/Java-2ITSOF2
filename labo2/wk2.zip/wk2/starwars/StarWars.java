package be.ap.wk2.starwars;

import be.ap.wk2.starwars.character.DarthVader;
import be.ap.wk2.starwars.character.LukeSkywalker;
import be.ap.wk2.starwars.trooper.Rank;
import be.ap.wk2.starwars.trooper.SortByNameComperator;
import be.ap.wk2.starwars.trooper.StormTrooper;

import java.util.*;

public class StarWars {

    public static void main(String[] args) {
        DarthVader vader = new DarthVader();
        LukeSkywalker luke = new LukeSkywalker();


        Ship<LukeSkywalker> xwing = new Ship<>();
        xwing.addPilot(new LukeSkywalker());

        Ship<DarthVader> tiefighter = new Ship<>();
        tiefighter.addPilot(new DarthVader());

        //Ship<StormTrooper> wrongship = new Ship<>();

        List<String> trooperNames = new ArrayList<>();
        trooperNames.add("trooper 3");
        trooperNames.add("trooper 2");
        trooperNames.add("trooper 1");

        Collections.sort(trooperNames);





        Iterator<String> iterator = trooperNames.iterator();
        while(iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        String[] names = new String[]{"Luke", "Vader"};

        System.out.println(names[0]);
        System.out.println(names.length);

        names[0] = "Luke Skywalker";
        System.out.println(names[0]);

        List<String> listNames = Arrays.asList(names);

        //String[] listNamesArray = (String[]) listNames.toArray();

        StormTrooper trooper1 = new StormTrooper("trooper A", Rank.SOLDIER);
        StormTrooper trooper2 = new StormTrooper("trooper B", Rank.SOLDIER);
        StormTrooper trooper3 = new StormTrooper("trooper C", Rank.SERGEANT);

        List<StormTrooper> troopers = new ArrayList<>();
        troopers.add(trooper3);
        troopers.add(trooper2);
        troopers.add(trooper1);

        //Collections.sort(troopers); //--> zelfde
        troopers.sort(Comparator.naturalOrder());
        System.out.println(troopers);

        //Collections.sort(troopers, new SortByNameComperator());
        troopers.sort(new SortByNameComperator());
        System.out.println(troopers);


        for (String listName : listNames) {
            
        }

        for (int i = 0; i < troopers.size(); i++) {
            
        }

        if(trooper1.equals(trooper2)) {
            System.out.println("ze zijn gelijk");
        } else {
            System.out.println("ze zijn niet gelijk");
        }
        System.out.println(trooper1.hashCode());
        System.out.println(trooper2.hashCode());
    }



}
