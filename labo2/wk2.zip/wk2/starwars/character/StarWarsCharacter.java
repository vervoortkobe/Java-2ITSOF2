package be.ap.wk2.starwars.character;

public abstract class StarWarsCharacter {
    private boolean forceUser;

    public StarWarsCharacter(boolean forceUser) {
        this.forceUser = forceUser;
    }

    public abstract String favoriteFightingStyle();
}
