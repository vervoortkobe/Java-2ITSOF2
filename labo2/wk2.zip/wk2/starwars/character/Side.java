package be.ap.wk2.starwars.character;

public enum Side {
    DARK, LIGHT
}
