package be.ap.wk2.starwars.character;

public class LukeSkywalker extends StarWarsCharacter {
    private Side side = Side.DARK;

    public LukeSkywalker() {
        super(true);
    }

    public Side getSide() {
        return side;
    }

    public String favoriteFightingStyle() {
        return "jump";
    }
}
