package labo8;

public enum AnimalType {
    CAT, DOG
}
