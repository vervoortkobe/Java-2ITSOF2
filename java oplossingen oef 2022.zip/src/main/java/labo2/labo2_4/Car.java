package labo2.labo2_4;



public class Car {
    int sequenceNumber;
    String brand;
}
