package labo3.labo3_5;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Set<String> stringSet = new HashSet<String>();
        stringSet.add("Hello");
        stringSet.add("Hello2");
        stringSet.add("Hello");
        System.out.println(stringSet);

        //Geen error gwn ignored
    }
}
