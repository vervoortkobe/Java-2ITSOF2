package labo10.model;

public enum PizzaSize {
	MEDIUM, LARGE
}
