package labo10.model;

public enum PizzaBottom {
	CLASSIC, PAN, CHEESYCRUST
}
