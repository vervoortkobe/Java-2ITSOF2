package labo4.labo4_1;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Chessboard chessboard = new Chessboard(4);
        chessboard.print();
    }
}
