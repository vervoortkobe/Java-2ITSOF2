package labo6.labo6_2.model;

public enum PizzaSize {
	MEDIUM, LARGE
}
