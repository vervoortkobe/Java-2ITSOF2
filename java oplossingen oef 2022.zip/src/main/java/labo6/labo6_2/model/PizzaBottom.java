package labo6.labo6_2.model;

public enum PizzaBottom {
	CLASSIC, PAN, CHEESYCRUST
}
