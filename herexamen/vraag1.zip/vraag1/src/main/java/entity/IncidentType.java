package entity;

public enum IncidentType {
    AGRESSIE, VERWONDING, DOODSLAG
}
