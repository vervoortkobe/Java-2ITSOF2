package incident;

public enum AgressionType {
    AGRESSION, INJURY, MANSLAUGHTER
}
