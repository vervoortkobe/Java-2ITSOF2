package incident;

public enum BearType {
    BRUINE_BEER, IJSBEER, TEDDYBEER, BRILBEER, REUZENPANDA
}
