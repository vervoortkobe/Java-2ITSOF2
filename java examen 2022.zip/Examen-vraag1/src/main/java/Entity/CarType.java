package Entity;

public enum CarType {
    SUV, BREAK, SEDAN, HATCHBACK, SPORT
}
