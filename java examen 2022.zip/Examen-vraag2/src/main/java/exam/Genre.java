package exam;

public enum Genre {
	DRAMA, ADVENTURE, ACTION, CRIME, TRILLER
}
