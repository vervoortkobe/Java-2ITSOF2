package controller;

public class ReportDTO {
    private String animalName;
    private Integer amount;

    public void setAnimalName(String animalName) {
        this.animalName = animalName;
    }

    public String getAnimalName() {
        return animalName;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return "ReportDTO{" +
                "animalName='" + animalName + '\'' +
                ", amount=" + amount +
                '}';
    }
}
