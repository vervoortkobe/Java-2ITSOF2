package controller;

import java.time.LocalDate;

public class DonationDTO {
    private int id;
    private int animalId;
    private String animalName;
    private int donorId;
    private String donorName;
    private LocalDate date;
    private Integer amount;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAnimalId() {
        return animalId;
    }

    public void setAnimalId(int animalId) {
        this.animalId = animalId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public void setAnimalName(String animalName) {
        this.animalName = animalName;
    }

    public int getDonorId() {
        return donorId;
    }

    public void setDonorId(int donorId) {
        this.donorId = donorId;
    }

    public String getDonorName() {
        return donorName;
    }

    public void setDonorName(String donorName) {
        this.donorName = donorName;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "DonationDTO{" +
                "id=" + id +
                ", animalId=" + animalId +
                ", animalName='" + animalName + '\'' +
                ", donorId=" + donorId +
                ", donorName='" + donorName + '\'' +
                ", date=" + date +
                ", amount=" + amount +
                '}';
    }
}
