package controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import dao.AnimalDAO;
import dao.DonationDAO;
import dao.DonorDAO;
import entity.Animal;
import entity.Donation;
import entity.Donor;
import service.DonationException;
import service.DonorException;
import service.WWFService;

public class WWFController {

    private final WWFService service;

    public WWFController() {
        AnimalDAO animalDAO = new AnimalDAO();
        DonorDAO donorDAO = new DonorDAO();
        DonationDAO donationDAO = new DonationDAO();

        this.service = new WWFService(animalDAO, donorDAO, donationDAO);
    }

    public void loadAllAnimals() {
        File input = new File("src/main/resources/animals.txt");

        try {
            Files.lines(input.toPath())
                    .map(this::stringToAnimal)
                    .forEach(animal -> service.addAnimal(animal));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Animal stringToAnimal(String line) {
        String[] split = line.split(",");
        return new Animal(split[0], Boolean.valueOf(split[1]));
    }

    public void createDonor(DonorDTO dto) throws DonorException {
        service.addDonor(dto.getName(), dto.getCompany());
    }

    public void createDonation(DonationDTO dto) throws DonationException {
        service.addDonation(dto.getAnimalName(), dto.getDonorName(), dto.getDate(), dto.getAmount());
    }

    public List<AnimalDTO> findAllAnimals() {
        List<Animal> animals = service.findAllAnimals();
        return animals.stream().map(this::assemble).collect(Collectors.toList());
    }

    public List<DonorDTO> findAllDonors() {
        List<Donor> donors = service.findAllDonors();
        return donors.stream().map(this::assemble).collect(Collectors.toList());
    }

    public List<DonationDTO> findAllDonations() {
        List<Donation> donations = service.findAllDonations();
        return donations.stream().map(this::assemble).collect(Collectors.toList());
    }

    public List<ReportDTO> reportDonations() {
        List<ReportDTO> reports = new ArrayList<>();
        Map<Animal, Integer> map = service.reportDonations();
        for (Animal animal : map.keySet()) {
            ReportDTO dto = new ReportDTO();
            dto.setAnimalName(animal.getName());
            dto.setAmount(map.get(animal));
            reports.add(dto);
        }
        return reports;
    }

    public void generateForTax(int year) {
        Map<Donor, Integer> reports = service.generateForTax(year);

        List<String> lines = new ArrayList<>();
        for (Donor donor : reports.keySet()) {
            lines.add(donor.getName() + " - " + reports.get(donor));
        }

        File output = new File("src/main/resources/output.txt");
        try {
            Files.write(output.toPath(), lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private AnimalDTO assemble(Animal animal) {
        AnimalDTO dto = new AnimalDTO();
        dto.setId(animal.getId());
        dto.setName(animal.getName());
        dto.setEndangered(animal.getEndangered());
        return dto;
    }

    private DonorDTO assemble(Donor donor) {
        DonorDTO dto = new DonorDTO();
        dto.setId(donor.getId());
        dto.setName(donor.getName());
        dto.setCompany(donor.getCompany());
        return dto;
    }

    private DonationDTO assemble(Donation donation) {
        DonationDTO dto = new DonationDTO();
        dto.setId(donation.getId());
        dto.setAnimalId(donation.getAnimal().getId());
        dto.setAnimalName(donation.getAnimal().getName());
        dto.setDonorId(donation.getDonor().getId());
        dto.setDonorName(donation.getDonor().getName());
        dto.setDate(donation.getDate());
        dto.setAmount(donation.getAmount());
        return dto;
    }
}
