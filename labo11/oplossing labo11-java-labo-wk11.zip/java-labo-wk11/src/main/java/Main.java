import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import controller.AnimalDTO;
import controller.DonationDTO;
import controller.DonorDTO;
import controller.ReportDTO;
import controller.WWFController;
import service.DonationException;
import service.DonorException;

public class Main {

    public static void main(String[] args) {
        WWFController controller = new WWFController();

        controller.loadAllAnimals();

        System.out.println("WWF Giften Systeem");
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        while (choice != 9) {
            System.out.println("Maak je keuze uit volgende opties");
            System.out.println("1 : Voeg persoon toe");
            System.out.println("2 : Voeg bedrijf toe");
            System.out.println("3 : Toon alle schenkers");
            System.out.println("4 : Toon alle dieren");
            System.out.println("5 : Voeg een schenking toe");
            System.out.println("6 : Toon alle schenkingen");
            System.out.println("7 : Rapporteer schenkingen");
            System.out.println("8 : Genereer belastingsvoordeel");
            System.out.println("9 : einde");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    System.out.println("Voeg een persoon toe:");
                    addDonor(controller, scanner, false);
                    break;
                case 2:
                    System.out.println("Voeg een bedrijf toe:");
                    addDonor(controller, scanner, true);
                    break;
                case 3:
                    System.out.println("Alle schenkers:");
                    List<DonorDTO> donors = controller.findAllDonors();
                    System.out.println(donors);
                    break;
                case 4:
                    System.out.println("Alle dieren:");
                    List<AnimalDTO> animals = controller.findAllAnimals();
                    System.out.println(animals);
                    break;
                case 5:
                    System.out.println("Voeg een schenking toe:");
                    addDonation(controller, scanner);
                    break;
                case 6:
                    System.out.println("Alle schenkingen:");
                    List<DonationDTO> donations = controller.findAllDonations();
                    System.out.println(donations);
                    break;
                case 7:
                    System.out.println("Rapporteer schenkingen:");
                    List<ReportDTO> reports = controller.reportDonations();
                    System.out.println(reports);
                    break;
                case 8:
                    System.out.println("Genereer belastingsvoordeel:");
                    System.out.println("Geef jaartal in (jjjj):");
                    int year = scanner.nextInt();
                    scanner.nextLine();
                    controller.generateForTax(year);
                    break;
                default:
                    choice = 9;
                    break;

            }
        }
    }

    private static void addDonor(WWFController controller, Scanner scanner, boolean isCompany) {
        System.out.println("Geef de naam in:");
        String name = scanner.nextLine();

        DonorDTO dto = new DonorDTO();
        dto.setName(name);
        dto.setCompany(isCompany);

        try {
            controller.createDonor(dto);
        } catch (DonorException e) {
            System.out.println("Deze schenker bestaat al.");
        }
    }

    private static void addDonation(WWFController controller, Scanner scanner) {
        System.out.println("Geef de naam van het dier in:");
        String animalName = scanner.nextLine();
        System.out.println("Geef de naam van de schenker in:");
        String donorName = scanner.nextLine();
        System.out.println("Geef de datum (dd-mm-jjjj) in:");
        String date = scanner.nextLine();
        System.out.println("Geef het bedrag in:");
        int amount = scanner.nextInt();
        scanner.nextLine();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        DonationDTO dto = new DonationDTO();
        dto.setAnimalName(animalName);
        dto.setDonorName(donorName);
        dto.setDate(LocalDate.parse(date, formatter));
        dto.setAmount(amount);

        try {
            controller.createDonation(dto);
        } catch (DonationException e) {
            if (e.getType().equals("amount")) {
                System.out.println("Het bedrag met positief zijn.");
            }
            if (e.getType().equals("donor")) {
                System.out.println("De schenker moet gekend zijn in het systeem");
            }
            if (e.getType().equals("animal")) {
                System.out.println("Het dier moet gekend zijn in het systeem");
            }
        }
    }
}
