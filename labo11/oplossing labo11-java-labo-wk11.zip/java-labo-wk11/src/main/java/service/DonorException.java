package service;

public class DonorException extends Exception {
}
