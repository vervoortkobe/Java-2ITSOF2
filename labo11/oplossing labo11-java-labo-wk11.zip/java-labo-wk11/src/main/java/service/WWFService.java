package service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import dao.AnimalDAO;
import dao.DonationDAO;
import dao.DonorDAO;
import entity.Animal;
import entity.Donation;
import entity.Donor;

public class WWFService {
    private final AnimalDAO animalDAO;
    private final DonorDAO donorDAO;
    private final DonationDAO donationDAO;

    public WWFService(AnimalDAO animalDAO, DonorDAO donorDAO, DonationDAO donationDAO) {
        this.animalDAO = animalDAO;
        this.donorDAO = donorDAO;
        this.donationDAO = donationDAO;
    }

    public void addAnimal(Animal animal) {
        this.animalDAO.create(animal);
    }

    public void addDonor(String name, Boolean company) throws DonorException {
        if (this.donorDAO.exists(name)) {
            throw new DonorException();
        } else {
            this.donorDAO.create(new Donor(name, company));
        }
    }

    public void addDonation(String animalName, String donorName, LocalDate date, Integer amount) throws DonationException {
        Animal animal = this.animalDAO.findAll().stream().filter(p -> p.getName().equals(animalName)).findFirst().orElse(null);
        Donor donor = this.donorDAO.findAll().stream().filter(p -> p.getName().equals(donorName)).findFirst().orElse(null);
        if (animal == null) {
            throw new DonationException("animal");
        }
        if (donor == null) {
            throw new DonationException("donor");
        }
        if (amount < 0) {
            throw new DonationException("amount");
        }
        this.donationDAO.create(new Donation(animal, donor, date, amount));
    }

    public List<Animal> findAllAnimals() {
        return this.animalDAO.findAll();
    }

    public List<Donor> findAllDonors() {
        return this.donorDAO.findAll();
    }

    public List<Donation> findAllDonations() {
        return this.donationDAO.findAll().stream()
                .sorted((o1, o2) -> {
                    int i = o1.getDate().compareTo(o2.getDate());
                    if (i == 0) {
                        return o1.getDonor().getName().compareTo(o2.getDonor().getName());
                    }
                    return i;
                })
                .collect(Collectors.toList());
    }

    public Map<Animal, Integer> reportDonations() {
        List<Donation> donations = donationDAO.findAll();
        Map<Animal, Integer> report = new HashMap<>();
        for (Donation donation : donations) {
            if (report.containsKey(donation.getAnimal())) {
                report.put(donation.getAnimal(), report.get(donation.getAnimal()) + donation.getAmount());
            } else {
                report.put(donation.getAnimal(), donation.getAmount());
            }
        }
        return report;
    }

    public Map<Donor, Integer> generateForTax(int year) {
        //alle schenkingen voor jaar = year && donor != company
        List<Donation> donations = donationDAO.findAll().stream()
                .filter(donation -> donation.getDate().getYear() == year)
                .filter(donation -> !donation.getDonor().getCompany())
                .collect(Collectors.toList());
        //alle schenkingen per donor
        Map<Donor, Integer> report = new HashMap<>();
        for (Donation donation : donations) {
            if (report.containsKey(donation.getDonor())) {
                report.put(donation.getDonor(), report.get(donation.getDonor()) + donation.getAmount());
            } else {
                report.put(donation.getDonor(), donation.getAmount());
            }
        }
        //totaal schenkingen < 100 eruit
        for (Donor donor : report.keySet()) {
            if (report.get(donor) < 100) {
                report.remove(donor);
            }
        }
        return report;
    }
}
