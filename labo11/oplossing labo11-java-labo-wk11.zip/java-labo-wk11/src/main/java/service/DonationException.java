package service;

public class DonationException extends Exception {
    private String type;

    public DonationException(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
