package util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Animal;
import entity.Donation;
import entity.Donor;

public class HibernateUtil {
    private static SessionFactory sessionFactory;

    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            try {
                Configuration configuration = new Configuration();
                configuration.configure("hibernate.cfg.xml");
                configuration.addAnnotatedClass(Animal.class);
                configuration.addAnnotatedClass(Donor.class);
                configuration.addAnnotatedClass(Donation.class);
                sessionFactory = configuration.buildSessionFactory();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return sessionFactory;
    }
}