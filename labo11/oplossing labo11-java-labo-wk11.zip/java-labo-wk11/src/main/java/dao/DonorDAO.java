package dao;

import java.util.List;
import java.util.Optional;

import org.hibernate.Session;
import org.hibernate.Transaction;

import entity.Donor;
import util.HibernateUtil;

public class DonorDAO {

    public void create(Donor donor) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(donor);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public boolean exists(String name) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            List<Donor> donors = session.createQuery("SELECT s FROM Donor s WHERE s.name = '" + name + "'", Donor.class).list();
            return donors.size() > 0;
        }
    }

    public List<Donor> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT s FROM Donor s", Donor.class).list();
        }
    }

    public Optional<Donor> findById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return Optional.ofNullable(session.get(Donor.class, id));
        }
    }
}
