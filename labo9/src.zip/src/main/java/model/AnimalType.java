package model;

public enum AnimalType {
    CAT, DOG
}
