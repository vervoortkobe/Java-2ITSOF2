package clinic;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

import model.Animal;
import model.AnimalType;

class AnimalClinicV1Test {

    @Test
    void addAnimalCheckAdded() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");

        int result = clinic.addAnimal(animal);
        assertEquals(1, result);
    }

    @Test
    void addTwoAnimalsBothSameOnlyOneAdded() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");

        //add animal
        clinic.addAnimal(animal);
        //add same animal
        int result = clinic.addAnimal(animal);
        assertEquals(1, result);
    }

    @Test
    void addTwoAnimalsBothAdded() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");

        //add animal
        clinic.addAnimal(animal1);
        //add other animal
        int result = clinic.addAnimal(animal2);
        assertEquals(2, result);
    }

    @Test
    void findAnimal() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        clinic.addAnimal(animal);

        Animal result = clinic.findAnimal("Pluisje", AnimalType.CAT);
        assertEquals(animal, result);
    }

    @Test
    void findAnimalTwoAnimals() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        clinic.addAnimal(animal1);
        clinic.addAnimal(animal2);

        Animal result = clinic.findAnimal("Pluisje", AnimalType.CAT);
        assertEquals(animal1, result);
    }

    @Test
    void findAnimalNotFound() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        clinic.addAnimal(animal);

        Animal result = clinic.findAnimal("Brutus", AnimalType.DOG);
        assertNull(result);
    }

    @Test
    void countAnimalsZeroAdded() {
        AnimalClinicV1 clinic = new AnimalClinicV1();

        int result = clinic.countAnimals();
        assertEquals(0, result);
    }

    @Test
    void countAnimalsTenAdded() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        for (int i = 0; i < 10; i++) {
            Animal animal = new Animal("Test" + i, AnimalType.CAT, "De Vos");
            clinic.addAnimal(animal);
        }
        int result = clinic.countAnimals();
        assertEquals(10, result);
    }

    @Test
    void findAnimalsForOwnerDeVos() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        clinic.addAnimal(animal1);
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        clinic.addAnimal(animal2);
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");
        clinic.addAnimal(animal3);

        List<Animal> result = clinic.findAllAnimalsForOwner("De Vos");

        assertEquals(2, result.size());
        assertTrue(result.contains(animal1));
        assertTrue(result.contains(animal2));
    }

    @Test
    void findAnimalsForOwnerHerman() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        clinic.addAnimal(animal1);
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        clinic.addAnimal(animal2);
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");
        clinic.addAnimal(animal3);

        List<Animal> result = clinic.findAllAnimalsForOwner("Herman");

        assertEquals(1, result.size());
        assertTrue(result.contains(animal3));
    }

    @Test
    void findAnimalsForOwnerUnkown() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        clinic.addAnimal(animal1);
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        clinic.addAnimal(animal2);
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");
        clinic.addAnimal(animal3);

        List<Animal> result = clinic.findAllAnimalsForOwner("Unkown");

        assertEquals(0, result.size());
    }

    @Test
    void changeOwner() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        clinic.addAnimal(animal);

        boolean result = clinic.changeAnimalOwner("Pluisje", AnimalType.CAT, "Herman");
        assertTrue(result);
        Animal updated = clinic.findAnimal("Pluisje", AnimalType.CAT);
        assertEquals("Dils", updated.getOwner());
    }

    @Test
    void changeOwnerUnknownAnimal() {
        AnimalClinicV1 clinic = new AnimalClinicV1();
        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        clinic.addAnimal(animal);

        boolean result = clinic.changeAnimalOwner("Brutus", AnimalType.DOG, "Herman");
        assertFalse(result);
    }
}