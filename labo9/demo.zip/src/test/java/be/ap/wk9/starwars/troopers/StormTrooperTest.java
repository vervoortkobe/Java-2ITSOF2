package be.ap.wk9.starwars.troopers;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
class StormTrooperTest {

    @Test
    void testCreateTrooper() {
        StormTrooper trooper = new StormTrooper("Test", Rank.TROOPER);
        assertEquals("Test", trooper.getName());
        assertEquals(Rank.TROOPER, trooper.getRank());
    }
}