package be.ap.wk9.starwars.troopers;

import be.ap.wk9.starwars.dao.SquadDAO;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SquadServiceTest {

    @Test
    void findAllSquadNames() {
        SquadDAO squadDAO = mock(SquadDAO.class);

        SquadService service = new SquadService(squadDAO, null);

        when(squadDAO.getSquads())
                .thenReturn(
                        Arrays.asList(new Squad("Test1"), new Squad("Test2"))
                );

        List<String> allSquadNames = service.findAllSquadNames();
        assertEquals(2, allSquadNames.size());
    }

    @Test
    void createNewSquad() {
        SquadDAO squadDAO = mock(SquadDAO.class);

        SquadService service = new SquadService(squadDAO, null);

        Squad squad = new Squad("test");
        service.createNewSquad(squad);

        verify(squadDAO, times(1)).createSquad(squad);

    }
}