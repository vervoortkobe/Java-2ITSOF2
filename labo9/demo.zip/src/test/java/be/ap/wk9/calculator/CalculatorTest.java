package be.ap.wk9.calculator;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalculatorTest {

    @Test
    void addOneAndTwoIsThree() {
        Calculator calc = new Calculator();
        int result = calc.add(1, 2);
        assertEquals(3, result);
    }

    @Test
    void addOneAndThreeIsFour() {
        Calculator calc = new Calculator();
        int result = calc.add(1, 3);
        assertEquals(4, result);
    }

    @Test
    void addTwoAndThreeIsFive() {
        Calculator calc = new Calculator();
        int result = calc.add(2, 3);
        assertEquals(5, result);
    }

    @Test
    void addToResultThreeOneIsFour() {
        Calculator calc = new Calculator();
        calc.add(1, 2);
        int result = calc.addToResult(1);
        assertEquals(result, 4);
    }

    @Test
    void addToResultThreeTwoIsFive() {
        Calculator calc = new Calculator();
        calc.add(1, 2);
        int result = calc.addToResult(2);
        assertEquals(result, 5);
    }

    @Test
    void addToResultFourTwoIsSix() {
        Calculator calc = new Calculator();
        calc.add(1, 3);
        int result = calc.addToResult(2);
        assertEquals(result, 6);
    }
}
