package be.ap.wk9.starwars.troopers;

public enum Rank {
    TROOPER, SERGEANT
}
