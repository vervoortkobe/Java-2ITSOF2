package be.ap.wk9.starwars.troopers;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "SQUAD")
public class Squad {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "SQUAD_TROOPER")
    private Set<StormTrooper> troopers;

    public Squad() {
    }

    public Squad(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<StormTrooper> getTroopers() {
        return troopers;
    }

    public void setTroopers(Set<StormTrooper> troopers) {
        this.troopers = troopers;
    }

    public void addTrooper(StormTrooper trooper) {
        if (this.troopers == null) {
            this.troopers = new HashSet<>();
        }
        this.troopers.add(trooper);
    }

    @Override
    public String toString() {
        return "Squad{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", troopers=" + troopers +
                '}';
    }
}
