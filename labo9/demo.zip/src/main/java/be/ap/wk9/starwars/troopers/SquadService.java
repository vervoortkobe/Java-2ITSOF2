package be.ap.wk9.starwars.troopers;

import be.ap.wk9.starwars.dao.SquadDAO;
import be.ap.wk9.starwars.dao.StormTrooperDAO;

import java.util.List;
import java.util.stream.Collectors;

public class SquadService {

    private final SquadDAO squadDAO;
    private final StormTrooperDAO stormTrooperDAO;

    public SquadService(SquadDAO squadDAO, StormTrooperDAO stormTrooperDAO) {
        this.squadDAO = squadDAO;
        this.stormTrooperDAO = stormTrooperDAO;
    }

    public List<String> findAllSquadNames() {
        List<Squad> squads = squadDAO.getSquads();
        return squads.stream()
                .map(squad -> squad.getName())
                .collect(Collectors.toList());
    }

    public Squad createNewSquad(Squad squad) {
        if(!squad.getName().equals("test")) {
            squadDAO.createSquad(squad);
        }

        return squad;
    }

    public void addNewSergeantToSquad(Squad squad, String trooperName) {
        StormTrooper stormTrooper = new StormTrooper(trooperName, Rank.SERGEANT);
        stormTrooperDAO.createStormTrooper(stormTrooper);
        squad.addTrooper(stormTrooper);
        squadDAO.updateSquad(squad);
    }

    public void addNewTrooperToSquad(Squad squad, String trooperName) {
        StormTrooper stormTrooper = new StormTrooper(trooperName, Rank.TROOPER);
        stormTrooperDAO.createStormTrooper(stormTrooper);
        squad.addTrooper(stormTrooper);
        squadDAO.updateSquad(squad);
    }
}
