package be.ap.wk9.calculator;

public class Calculator {
    int memory;

    public int add(int first, int second) {
        memory = first + second;
        return memory;
    }

    public int addToResult(int value) {
        return memory + value;
    }
}
