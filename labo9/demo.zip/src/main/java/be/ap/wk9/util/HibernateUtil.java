package be.ap.wk9.util;

import be.ap.wk9.starwars.troopers.Squad;
import be.ap.wk9.starwars.troopers.StormTrooper;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
    private static SessionFactory sessionFactory;

    public static SessionFactory getSessionFactory() {
        if(sessionFactory == null) {
            try {
                Configuration configuration = new Configuration();
                configuration.configure("hibernate-h2.cfg.xml");
                configuration.addAnnotatedClass(StormTrooper.class);
                configuration.addAnnotatedClass(Squad.class);
                sessionFactory = configuration.buildSessionFactory();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return sessionFactory;
    }

}
