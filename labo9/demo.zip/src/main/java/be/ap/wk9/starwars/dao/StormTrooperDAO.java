package be.ap.wk9.starwars.dao;

import be.ap.wk9.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;
import java.util.Optional;

public class StormTrooperDAO {

    public List<be.ap.wk9.starwars.troopers.StormTrooper> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT v FROM StormTrooper v", be.ap.wk9.starwars.troopers.StormTrooper.class).list();
        }
    }

    public Optional<be.ap.wk9.starwars.troopers.StormTrooper> findById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return Optional.ofNullable(session.get(be.ap.wk9.starwars.troopers.StormTrooper.class, id));
        }
    }

    public void createStormTrooper(be.ap.wk9.starwars.troopers.StormTrooper trooper) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.persist(trooper);

            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
        }
    }

    public void updateStormTrooper(be.ap.wk9.starwars.troopers.StormTrooper trooper) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.merge(trooper);

            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
        }
    }

    public void deleteStormTrooper(be.ap.wk9.starwars.troopers.StormTrooper trooper) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.remove(trooper);

            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
        }
    }

}
