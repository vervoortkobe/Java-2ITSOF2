package clinic;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

import dao.AnimalDAO;
import model.Animal;
import model.AnimalType;

class AnimalClinicV2Test {

    @Test
    void addAnimalCheckAdded() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);
        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");

        when(dao.existAnimal(animal)).thenReturn(false);

        clinic.addAnimal(animal);

        verify(dao, times(1)).createAnimal(animal);
    }

    @Test
    void addTwoAnimalsBothSameOnlyOneAdded() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);
        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");

        //add animal
        when(dao.existAnimal(animal)).thenReturn(false);
        clinic.addAnimal(animal);

        //add same animal
        when(dao.existAnimal(animal)).thenReturn(true);
        clinic.addAnimal(animal);

        verify(dao, times(1)).createAnimal(animal);
    }

    @Test
    void addTwoAnimalsBothAdded() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);
        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");

        //add animal
        when(dao.existAnimal(animal1)).thenReturn(false);
        clinic.addAnimal(animal1);

        //add same animal
        when(dao.existAnimal(animal2)).thenReturn(false);
        clinic.addAnimal(animal2);

        verify(dao, times(1)).createAnimal(animal1);
        verify(dao, times(1)).createAnimal(animal2);
    }

    @Test
    void findAnimal() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        when(dao.findAll()).thenReturn(Arrays.asList(animal));

        Animal result = clinic.findAnimal("Pluisje", AnimalType.CAT);
        assertEquals(animal, result);
    }

    @Test
    void findAnimalTwoAnimals() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        when(dao.findAll()).thenReturn(Arrays.asList(animal1, animal2));

        Animal result = clinic.findAnimal("Pluisje", AnimalType.CAT);
        assertEquals(animal1, result);
    }

    @Test
    void findAnimalNotFound() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        when(dao.findAll()).thenReturn(Arrays.asList(animal));

        Animal result = clinic.findAnimal("Brutus", AnimalType.DOG);
        assertNull(result);
    }

    @Test
    void countAnimalsZeroAdded() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        when(dao.findAll()).thenReturn(new ArrayList<>());

        int result = clinic.countAnimals();
        assertEquals(0, result);
    }

    @Test
    void countAnimalsTenAdded() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        List<Animal> animals = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Animal animal = new Animal("Test" + i, AnimalType.CAT, "De Vos");
            animals.add(animal);
        }
        when(dao.findAll()).thenReturn(animals);

        int result = clinic.countAnimals();
        assertEquals(10, result);
    }

    @Test
    void findAnimalsForOwnerDeVos_size2() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");

        when(dao.findAll()).thenReturn(Arrays.asList(animal1, animal2, animal3));

        List<Animal> result = clinic.findAllAnimalsForOwner("De Vos");

        assertEquals(2, result.size());
    }

    @Test
    void findAnimalsForOwnerDeVos_contains_animal1() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");

        when(dao.findAll()).thenReturn(Arrays.asList(animal1, animal2, animal3));

        List<Animal> result = clinic.findAllAnimalsForOwner("De Vos");

        assertTrue(result.contains(animal1));
    }

    @Test
    void findAnimalsForOwnerDeVos_contains_animal2() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");

        when(dao.findAll()).thenReturn(Arrays.asList(animal1, animal2, animal3));

        List<Animal> result = clinic.findAllAnimalsForOwner("De Vos");

        assertTrue(result.contains(animal2));
    }

    @Test
    void findAnimalsForOwnerDeVos_notcontains_animal3() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");

        when(dao.findAll()).thenReturn(Arrays.asList(animal1, animal2, animal3));

        List<Animal> result = clinic.findAllAnimalsForOwner("De Vos");

        assertFalse(result.contains(animal3));
    }

    @Test
    void findAnimalsForOwnerHerman_size1() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");

        when(dao.findAll()).thenReturn(Arrays.asList(animal1, animal2, animal3));

        List<Animal> result = clinic.findAllAnimalsForOwner("Herman");

        assertEquals(1, result.size());
    }

    @Test
    void findAnimalsForOwnerHerman_notcontains_animal1() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");

        when(dao.findAll()).thenReturn(Arrays.asList(animal1, animal2, animal3));

        List<Animal> result = clinic.findAllAnimalsForOwner("Herman");

        assertFalse(result.contains(animal1));
    }

    @Test
    void findAnimalsForOwnerHerman_notcontains_animal2() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");

        when(dao.findAll()).thenReturn(Arrays.asList(animal1, animal2, animal3));

        List<Animal> result = clinic.findAllAnimalsForOwner("Herman");

        assertFalse(result.contains(animal2));
    }

    @Test
    void findAnimalsForOwnerHerman_contains_animal3() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");

        when(dao.findAll()).thenReturn(Arrays.asList(animal1, animal2, animal3));

        List<Animal> result = clinic.findAllAnimalsForOwner("Herman");

        assertTrue(result.contains(animal3));
    }

    @Test
    void findAnimalsForOwnerUnkown() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal1 = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        Animal animal2 = new Animal("Brutus", AnimalType.DOG, "De Vos");
        Animal animal3 = new Animal("Fifi", AnimalType.DOG, "Herman");

        when(dao.findAll()).thenReturn(Arrays.asList(animal1, animal2, animal3));

        List<Animal> result = clinic.findAllAnimalsForOwner("Unkown");

        assertEquals(0, result.size());
    }

    @Test
    void changeOwner() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        when(dao.findAll()).thenReturn(Arrays.asList(animal));

        boolean result = clinic.changeAnimalOwner("Pluisje", AnimalType.CAT, "Herman");
        assertTrue(result);
    }

    @Test
    void changeOwnerUnknownAnimal() {
        AnimalDAO dao = mock(AnimalDAO.class);
        AnimalClinicV2 clinic = new AnimalClinicV2(dao);

        Animal animal = new Animal("Pluisje", AnimalType.CAT, "De Vos");
        when(dao.findAll()).thenReturn(Arrays.asList(animal));

        boolean result = clinic.changeAnimalOwner("Brutus", AnimalType.DOG, "Herman");
        assertFalse(result);
    }
}