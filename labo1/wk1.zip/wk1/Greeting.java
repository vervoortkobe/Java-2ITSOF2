package be.ap.wk1;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Greeting {

    private final String fullName;

    //default constructor
    public Greeting() {
        this.fullName = "default";
    }

    //overload
    public Greeting(String fullName) {
        this.fullName = fullName;
    }

    public String getPersonalGreeting(String firstName, String lastName) {
        return "Hello " + firstName + " " + lastName;
    }

    public void calculate() {

        LocalDateTime from = LocalDateTime.of(2023, 1, 1, 0, 0);
        LocalDateTime now = LocalDateTime.now();

        Duration duration = Duration.between(from, now);

        System.out.println(duration.toHours());

        LocalDate birthDate = LocalDate.of(1975, 1, 14);

        Duration duration2 = Duration.between(birthDate.atStartOfDay(), now);

        String myBirthDay = "01-14-1975";

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDateTime birthDay2 = LocalDateTime.parse(myBirthDay, formatter);

        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
        String date = now.format(formatter2);

        System.out.println(date);
    }
}
