package be.ap.wk1.starwars.character;

public class LukeSkywalker extends StarWarsCharacter implements Weapon {

    public LukeSkywalker() {
        super(true);
    }

    public String favoriteFightingStyle() {
        return "jump";
    }

    public String getMyWeapon() {
        return "lightsaber";
    }
}
