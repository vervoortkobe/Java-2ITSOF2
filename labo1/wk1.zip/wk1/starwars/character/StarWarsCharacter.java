package be.ap.wk1.starwars.character;

public abstract class StarWarsCharacter {
    private boolean forceUser;

    public StarWarsCharacter(boolean forceUser) {
        this.forceUser = forceUser;
    }

    public abstract String favoriteFightingStyle();
}
