package be.ap.wk1.starwars.character;

public interface Weapon {
    String getMyWeapon();
}
