package be.ap.wk1.starwars.character;

public enum Side {
    DARK, LIGHT
}
