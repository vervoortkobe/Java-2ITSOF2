package be.ap.wk1.starwars.character;

public class DarthVader extends StarWarsCharacter {

    private Side side = Side.DARK;

    public DarthVader() {
        super(true);
    }

    public Side getSide() {
        return side;
    }

    public String favoriteFightingStyle() {
        return "throw lightsaber";
    }

}
