package be.ap.wk1.starwars;

import be.ap.wk1.starwars.character.*;

public class StarWars {

    public static void main(String[] args) {
        DarthVader vader = new DarthVader();
        LukeSkywalker luke = new LukeSkywalker();

        System.out.println("hello star wars");
    }



}
