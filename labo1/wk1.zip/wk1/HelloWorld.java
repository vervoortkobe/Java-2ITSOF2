package be.ap.wk1;

public class HelloWorld {

    private static final String GREETING = "Hello World";

    public String getGreeting(GreetingType type) {
        if(type == GreetingType.FORMAL) {

            Greeting greet = new Greeting();

            String hello = greet.getPersonalGreeting("Jeroen", "De Vos");

            System.out.println(hello);

        } else {

        }
        return "Hello World";
    }

    public String getPersonalGreeting(String firstName, String lastName) {
        String greeting = "Hello " + firstName + " " + lastName;
        return greeting;
    }

    public void updateGreeting(String firstName, String lastName) {
        //greeting = "Hello " + firstName + " " + lastName;

        Integer age = 48;
    }

}
