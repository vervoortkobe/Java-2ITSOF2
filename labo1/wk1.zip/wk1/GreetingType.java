package be.ap.wk1;

public enum GreetingType {
    FORMAL, INFORMAL, OTHER
}
