package animals;

public interface WildAnimal {
    boolean endangered();
}
