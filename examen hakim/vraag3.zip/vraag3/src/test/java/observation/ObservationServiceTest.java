package observation;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ObservationServiceTest {

    @Test
    void addObservation() {
        BearDAO bearDAO = mock(BearDAO.class);
        ObservationDAO observationDAO = mock(ObservationDAO.class);
        ObservationService observationService = new ObservationService(bearDAO, observationDAO);

        String name = "test";
        LocalDate date = LocalDate.now();
        Bear bear = new Bear(name);
        Optional<Observation> optionalObservation = Optional.empty();
        Observation observation = new Observation(bear, date);

        when(bearDAO.findByName(name)).thenReturn(bear);
        when(observationDAO.find(bear, date)).thenReturn(optionalObservation);

        boolean result = observationService.addObservation(observation.getBear().getName(), observation.getDate());
        assertEquals(true, result);
    }

    @Test
    void removeObservation() {
        BearDAO bearDAO = mock(BearDAO.class);
        ObservationDAO observationDAO = mock(ObservationDAO.class);
        ObservationService observationService = new ObservationService(bearDAO, observationDAO);

        String name = "test";
        LocalDate date = LocalDate.now();
        Bear bear = new Bear(name);
        Optional<Observation> observation = Optional.of(new Observation(bear, date));

        when(bearDAO.findByName(name)).thenReturn(bear);
        when(observationDAO.find(bear, date)).thenReturn(observation);

        boolean result = observationService.removeObservation(name, date);

        verify(observationDAO, times(1)).delete(observation.get());
        assertEquals(true, result);
    }

    @Test
    void findAll() {
        BearDAO bearDAO = mock(BearDAO.class);
        ObservationDAO observationDAO = mock(ObservationDAO.class);
        ObservationService observationService = new ObservationService(bearDAO, observationDAO);

        String name = "test";
        LocalDate date = LocalDate.now();
        Bear bear = new Bear(name);

        List<Observation> observationList = new ArrayList<>();
        observationList.add(new Observation(bear, date));

        when(observationDAO.findAll()).thenReturn(observationList);

        assertEquals(observationList, observationService.findAll());

    }

    @Test
    void findAllForBear() {
        BearDAO bearDAO = mock(BearDAO.class);
        ObservationDAO observationDAO = mock(ObservationDAO.class);
        ObservationService observationService = new ObservationService(bearDAO, observationDAO);

        String name = "test";
        LocalDate date = LocalDate.now();
        Bear bear = new Bear(name);

        when(bearDAO.findByName(name)).thenReturn(bear);


        List<Observation> observationList = new ArrayList<>();
        observationList.add(new Observation(bear, date));


        when(observationDAO.findAll()).thenReturn(observationList);

        assertEquals(observationList, observationService.findAllForBear(name));

    }
}