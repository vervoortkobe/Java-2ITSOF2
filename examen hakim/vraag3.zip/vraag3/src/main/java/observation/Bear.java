package observation;

public class Bear {
    private final String name;

    public Bear(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
