package bear.comparators;

import bear.BearSpotting;

import java.util.Comparator;

public class SortByLocationAndAccuracyAscending implements Comparator<BearSpotting> {
    @Override
    public int compare(BearSpotting o1, BearSpotting o2) {
        // Vergelijk op locatie alfabetisch
        int alfabeticComparison = o1.getLocation().toString().compareTo(o2.getLocation().toString());

        // Als de de locatie gelijk is, wordt er vergeleken op accuracy
        if (alfabeticComparison == 0) {
            int o1Accuracy = o1.getAccuracy();
            int o2Accuracy = o2.getAccuracy();

            return o1Accuracy - o2Accuracy;
        }
        return alfabeticComparison;

    }
}
