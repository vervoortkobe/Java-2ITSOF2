package bear;

public enum Location {
    ZWINSTREEK, SCHELDEVALLEI, GROENE_VALlEI, BOSLAND, HOGE_KEMPEN
}
