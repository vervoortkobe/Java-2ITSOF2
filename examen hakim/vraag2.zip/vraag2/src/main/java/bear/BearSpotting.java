package bear;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.Objects;

public class BearSpotting implements Comparable<BearSpotting> {
    private final LocalDate date;
    private final BearType type;
    private final Location location;
    private final int accuracy;

    public BearSpotting(LocalDate date, BearType type, Location location, int accuracy) {
        this.date = date;
        this.type = type;
        this.location = location;
        this.accuracy = accuracy;
    }

    public LocalDate getDate() {
        return date;
    }

    public BearType getType() {
        return type;
    }

    public Location getLocation() {
        return location;
    }

    public int getAccuracy() {
        return accuracy;
    }

    @Override
    public String toString() {
        return "BearSpotting{" +
                "date=" + date +
                ", type=" + type +
                ", location=" + location +
                ", accuracy=" + accuracy +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BearSpotting that)) return false;
        return accuracy == that.accuracy && Objects.equals(date, that.date) && type == that.type && location == that.location;
    }

    @Override
    public int hashCode() {
        return Objects.hash(date, type, location, accuracy);
    }

    @Override
    public int compareTo(BearSpotting o) {
        // Vergelijk op datum (aflopend)
        int dateComparison = o.getDate().compareTo(this .getDate());

        // Als de datums gelijk zijn, vergelijk op type
        if (dateComparison == 0) {
            BearType nameOne = this.type;
            BearType nameTwo = o.getType();

            return nameOne.toString().compareTo(nameTwo.toString());
        }

        return dateComparison;
    }
}
