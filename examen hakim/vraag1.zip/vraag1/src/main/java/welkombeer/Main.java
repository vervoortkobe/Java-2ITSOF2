package welkombeer;

import welkombeer.dao.BearDAO;
import welkombeer.dao.ParcDAO;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {



        //region Inlezen beren
        File bearFile = new File("src/main/resources/beren.txt");
        BearDAO bearDAO = new BearDAO();
        try {
           Files.lines(bearFile.toPath())
                   .filter(line -> line != "Teddybeer")
                   .map(line -> line.replaceAll(" ", ""))
                   .forEach(line -> bearDAO.createBear(new Bear(line)));


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        //endregion
        File parcFile = new File("src/main/resources/natuurparken.csv");
        ParcDAO parcDAO = new ParcDAO();

//        try {
//            Files.lines(parcFile.toPath())
//                    .skip(1)
//                    .map(line -> lineToParc(line))
//                    .forEach(parcDAO.createParc(););
//
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }


    }

    private static Parc lineToParc(String line){
        String[] arParc = line.split(";");
        return new Parc(arParc[0], arParc[1]);
    }
}
