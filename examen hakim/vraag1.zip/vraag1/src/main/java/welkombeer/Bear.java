package welkombeer;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "beren")
public class Bear {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "name")
    private String name;


    public Bear() {
    }

    public Bear(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Bear bears)) return false;
        return Objects.equals(name, bears.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
