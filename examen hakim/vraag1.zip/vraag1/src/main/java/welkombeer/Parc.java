package welkombeer;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "natuurparken")
public class Parc {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "name")
    private String name;
    @Column(name = "provence")
    private String provence;

    public Parc(String name, String provence) {
        this.name = name;
        this.provence = provence;
    }

    public Parc() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProvence() {
        return provence;
    }

    public void setProvence(String provence) {
        this.provence = provence;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Parc parcs)) return false;
        return Objects.equals(name, parcs.name) && Objects.equals(provence, parcs.provence);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, provence);
    }
}
