package welkombeer;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "waarnemingen")
public class Observation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "date")
    private LocalDate date;
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "parc_id")
    private Parc parc;
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "bears")
    private Set<Bear> bears;
    private  String info;

    public Observation(LocalDate date, Parc parc, Set<Bear> bears, String info) {
        this.date = date;
        this.parc = parc;
        this.bears = bears;
        this.info = info;
    }

    public Observation() {
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Parc getParc() {
        return parc;
    }

    public void setParc(Parc parc) {
        this.parc = parc;
    }

    public Set<Bear> getBears() {
        return bears;
    }

    public void setBears(Set<Bear> bears) {
        this.bears = bears;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Observation that)) return false;
        return Objects.equals(date, that.date) && Objects.equals(parc, that.parc) && Objects.equals(bears, that.bears) && Objects.equals(info, that.info);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date, parc, bears, info);
    }
}
