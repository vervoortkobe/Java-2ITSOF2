package welkombeer.dao;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import welkombeer.Bear;
import welkombeer.HibernateUtil;

import java.util.List;

public class BearDAO {
    public List<Bear> getBears() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "SELECT b FROM Bear b";
            Query<Bear> query = session.createQuery(hql, Bear.class);
            return query.list();
        }
    }

    public void createBear(Bear bear) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(bear);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
        }
    }

}