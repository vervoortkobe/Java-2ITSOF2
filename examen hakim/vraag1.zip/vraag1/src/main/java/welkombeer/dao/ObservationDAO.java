package welkombeer.dao;

public class ObservationDAO {
}
