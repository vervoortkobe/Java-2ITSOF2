package meteo;

public enum Location {
    ANTWERPEN, BRUSSEL, HASSELT
}
