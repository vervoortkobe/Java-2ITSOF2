# basic OOP 
```JAVA
class Animal {
    public void eat() {
        
    }
}
class Dog extends Animal {
    @Override
    public void eat() {
        
    }
}
```
# Maven (framework lol)

# Collections all SORTING types of list
```JAVA
List<String> list = new ArrayList<>();
List<String> list = new LinkedList<>();
List<String> list = new SortedList<>();
List<int> list = new BubbleSort<>();
```
# Annotations @Somthing
```JAVA
@Override
@MyCustomAnnotation(value = "custom value")
//API Annotation
@Entity
@Path("/example")
@Controller
```

## TABLE DATABASE
```JAVA
@Entity
@Table(name = "person")
class Person {
    @Id
    @GeneratedValue
    @Column(name = "person_id")
    private int id;
    @Column //if the var text match database name
    private String name;
    @Column
    private int age;
}
```
# Generics
```JAVA
class Box<T> {
    private T value;
    public T DoSomthing(T value) {
        return value;
    }
}
```

# Optional and Exception
## Optional
```JAVA
class MySomthing extends Exeptions{
    isSomthing(somthing2)
    {
        if(somthing > 0){
        return somthing; //mean oki
        }
        else if(somthing2 == 0){ //ow no it cant be 0 I ges
        throw new Exeption("randome texte"); // somthing wrong so throw custom exeption
        }
        else{
        return somthing2; // is ok to
        }
    }
}
void Main(){
    MySomthing somthing = new MySomthing();
    somthing.isSomthing(0);
}
```

## Exception & StackTrace (e.printStackTrace();)
- Checked exeption:
    Compiler weet dat er een fout gaat gebeuren.
- Unchecked Exeption:
    Compiler weet niet dat er een fout optreet.
CODE
```js
//try.catch
try
catch(parseExeception e)
e.printStackTrace(); // print fout en in welke lijk dat het is.
------------------------
try.catch.catch ...
// als het het een simple probleem
try
catch(parseExeception | classNotFoundExecption e)
//of
catch(parseExeception e)
catch(classNotFoundExecption e)
------------------------
try.catch.finally
try
catch(parseExeception e)
e.printStackTrace();
finally
```

# Streams (file reading)
```JAVA
String namePath = "src/main/MyFiles/eigenaars.txt";
File nameFile = new File(namePath);
Stream<String> persons = Files.lines(nameFile.toPath()); //split text per line in file to steam array
Stream<String> persons2 = Files.lines(nameFile.toPath()); //split text per line in file to steam array
//STREAM IS USED UP! stream is unusable
String[] titles = persons.findFirst().get().split(";"); //convert it as you want 
//you can only used lmada on non list stuff in java
List<List<String>> names = persons2.skip(1)
.filter()
.map()
.sorted()
.collect(Collectors.toList());
```

# Threading
```JAVA
import java.lang.Thread;
import java.lang.Runnable;

class Doubler extends Thread implements Runnable {
    private List<Integer> m_List;
    private Dice m_Dice;

    public Doubler(List<Integer> list, Dice dice) {
        m_List = list;
        m_Dice = dice;
    }

    @Override
    public void run() {
        synchronized (m_Dice) {
            m_List.add(m_Dice.roll());
        }
    }
}
//MAIN
Dice dice = new Dice();
List<Integer> List1 = new ArrayList<>();
List<Integer> List2 = new ArrayList<>();

Doubler doubler1 = new Doubler(List1, dice);
Doubler doubler2 = new Doubler(List2, dice);

Thread t1 = new Thread(doubler1);
Thread t2 = new Thread(doubler2);

t1.start();
t2.start();

while(t1.isAlive() || t2.isAlive()) 
{/*just wait or do what ever you want until its done.*/}
OR 
t1.join();
t2.join();
```


# Hibernate
```JAVA
@entity
@table (name = "table_name")
public class MyTable implements Comarable<table_name> {
    @id
    @generatedValue(strategy = GenerationType.IDENTITY)
    @column(name = "id")
    private int id;
    @column(name = "name")
    private String name;
    @column(name = "age")
    private int age;
    @enumeration (EnumType.STRING)
    @column(name = "gender")
    private Gender gender;

    public MyTable() {
        
    }
    public MyTable(String name, int age, Gender gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }
}
```

# JAX-RS en Jersey

## dependency 'Jersey Maven'
```JAVA
//JETTSERVER
public class JettServer {
    Server server;
    int port;
    public JettServer(int port) {
        this.port = port;
    }
    private void Setup() {
        server = new Server(port);
        ResourceConfig config = new ResourceConfig();
        //classes that you made can be added here and they wil use get sets
        // for example:
        config.register(Controller.class);

        ServletContextHandler handler = new ServletContextHandler();
        handler.addServlet(new ServletHolder(new ServletContainer(config)), "/*");
        server.setHandler(handler);
    }
    public void Start() {
        //API
        Setup();
        try {
            server.start();
            System.out.println("Server started on port" + port);
            System.out.println("Addres" + server.getURI().toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
// CONTROLER
public class Controller {
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello(@QueryParam("name") String name) {
        System.out.println("http://localhost:8080/test?name=yourName");
        return "Hello " + name;
    }
}
//MAIN
//START SERVER
JettServer server = new JettServer(8080);
```

# object check

```JAVA
if(obj instanceof String srt){
    //do something
}
if(obj instanceof Point(int x, int y)){
    // int h = x + y; //no need in p.x p.y/mute all
}

String s = switch(obj){
    case String srt -> str.toString();
    case Integer i -> i.toString();
    case Double d -> d.toString();
}
```
