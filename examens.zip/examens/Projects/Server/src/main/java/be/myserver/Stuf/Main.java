package be.myserver.Stuf;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        JettServer server = new JettServer(8080);
        server.Start();
    }
}