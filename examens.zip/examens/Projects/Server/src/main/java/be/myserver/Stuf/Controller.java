package be.myserver.Stuf;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
@Path("/test")
public class Controller {
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello(@QueryParam("name") String name) {
        System.out.println("http://localhost:8080/test?name=yourName");
        return "Hello " + name;
    }
}
