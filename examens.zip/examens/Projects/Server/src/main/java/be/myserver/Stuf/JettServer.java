package be.myserver.Stuf;
import org.eclipse.jetty.server.*;
import org.eclipse.jetty.servlet.*;
import org.glassfish.jersey.*;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;

public class JettServer {
    Server server;
    int port;
    public JettServer(int port) {
        this.port = port;
    }
    private void Setup() {
        server = new Server(port);
        ResourceConfig config = new ResourceConfig();
        //classes that you made can be added here and they wil use get sets
        // for example:
        config.register(Controller.class);

        ServletContextHandler handler = new ServletContextHandler();
        handler.addServlet(new ServletHolder(new ServletContainer(config)), "/*");
        server.setHandler(handler);
    }
    public void Start() {
        //API
        Setup();
        try {
            server.start();
            System.out.println("Server started on port" + port);
            System.out.println("Addres" + server.getURI().toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}







