package be.ap.wk10;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

@Path("/demo")
public class DemoController {

    @GET
    @Path("/hello")
    @Produces(MediaType.TEXT_PLAIN)
    public String getHelloWorld(@QueryParam("firstName") String firstName, @QueryParam("lastName") String lastName) {
        return "Hello " + firstName + " " + lastName;
    }
}
