package be.ap.wk10.starwars;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.Arrays;

@Path("star-wars")
public class StarWarsController {

    @GET
    @Path("/")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCharacter() {
        StarWarsCharacterDTO dto = new StarWarsCharacterDTO();

        dto.setFirstName("Luke");
        dto.setLastName("Skywalker");
        dto.setHomePlanet("Tatooine");
        dto.setAge(19);
        dto.setJedi(true);
        dto.setFriends(Arrays.asList("Han", "Chewie", "Leia"));
        dto.setFather("Darth Vader");

        return Response.ok().entity(dto).build();
    }

    @POST
    @Path("/")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response setCharacter(StarWarsCharacterDTO dto) {
        System.out.println(dto);

        return Response.ok().build();
    }
}
