package be.ap.wk10;

public class Main {
    public static void main(String[] args) {
        JettyServer server = new JettyServer();
        server.start();
    }
}
