package be.ap.wk10;

import be.ap.wk10.starwars.StarWarsController;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;

public class JettyServer {

    private Server server;

    public void start() {
        server = new Server(8080);

        //register API
        ResourceConfig config = new ResourceConfig();
        config.register(DemoController.class);
        config.register(StarWarsController.class);

        ServletContextHandler handler = new ServletContextHandler();
        handler.addServlet(new ServletHolder(new ServletContainer(config)), "/api/*");

        server.setHandler(handler);

        try {
            server.start();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
