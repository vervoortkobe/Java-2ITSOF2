package be.ap.wk10.starwars;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class StarWarsCharacterDTO {
    @JsonProperty("myFirstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("homePlanet")
    private String homePlanet;

    private Integer age;

    private Boolean jedi;

    private List<String> friends;

    @JsonIgnore
    private String father;



    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getHomePlanet() {
        return homePlanet;
    }

    public void setHomePlanet(String homePlanet) {
        this.homePlanet = homePlanet;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Boolean getJedi() {
        return jedi;
    }

    public void setJedi(Boolean jedi) {
        this.jedi = jedi;
    }

    public List<String> getFriends() {
        return friends;
    }

    public void setFriends(List<String> friends) {
        this.friends = friends;
    }

    public String getFather() {
        return father;
    }

    public void setFather(String father) {
        this.father = father;
    }

    @Override
    public String toString() {
        return "StarWarsCharacterDTO{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", homePlanet='" + homePlanet + '\'' +
                ", age=" + age +
                ", jedi=" + jedi +
                ", friends=" + friends +
                ", father='" + father + '\'' +
                '}';
    }
}
