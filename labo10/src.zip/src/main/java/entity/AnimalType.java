package entity;

public enum AnimalType {
    CAT, DOG
}
