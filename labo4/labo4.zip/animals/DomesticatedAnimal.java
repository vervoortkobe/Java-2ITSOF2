package animals;

public interface DomesticatedAnimal {
}
