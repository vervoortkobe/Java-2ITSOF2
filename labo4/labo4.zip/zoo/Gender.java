package zoo;

public enum Gender {
    MALE, FEMALE;
}
