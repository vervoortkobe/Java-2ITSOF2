package starwars.characters;

public enum Side {
    LIGHT, DARK
}
