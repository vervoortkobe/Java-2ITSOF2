package starwars.characters;

public enum Colour {
    RED, GREEN, BLUE
}
