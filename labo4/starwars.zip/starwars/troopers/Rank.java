package starwars.troopers;

public enum Rank {
    TROOPER, SERGEANT
}
