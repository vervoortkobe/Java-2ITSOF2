import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import starwars.characters.AnakinSkywalker;
import starwars.characters.DarthVader;
import starwars.characters.GeneralVeers;
import starwars.characters.HanSolo;
import starwars.characters.KyloRen;
import starwars.characters.LukeSkywalker;
import starwars.characters.ObiwanKenobi;
import starwars.characters.Rey;
import starwars.movies.StarWarsMovie;

public class Main {

    public static void main(String[] args) {

        List<StarWarsMovie> movies = new ArrayList<>();
        movies.add(new StarWarsMovie(1, "The Phantom Menace", LocalDate.of(1999, 1, 1),
                Arrays.asList(new ObiwanKenobi(), new AnakinSkywalker())));
        movies.add(new StarWarsMovie(2, "Attack of the Clones", LocalDate.of(2002, 1, 1),
                Arrays.asList(new ObiwanKenobi(), new AnakinSkywalker())));
        movies.add(new StarWarsMovie(3, "Revenge of the Sith", LocalDate.of(2005, 1, 1),
                Arrays.asList(new ObiwanKenobi(), new AnakinSkywalker(), new DarthVader())));
        movies.add(new StarWarsMovie(4, "A New Hope", LocalDate.of(1977, 1, 1),
                Arrays.asList(new ObiwanKenobi(), new LukeSkywalker(), new DarthVader(), new HanSolo())));
        movies.add(new StarWarsMovie(5, "The Empire Strikes Back", LocalDate.of(1980, 1, 1),
                Arrays.asList(new LukeSkywalker(), new DarthVader(), new HanSolo(), new GeneralVeers())));
        movies.add(new StarWarsMovie(6, "Return of the Jedi", LocalDate.of(1983, 1, 1),
                Arrays.asList(new LukeSkywalker(), new DarthVader(), new HanSolo(), new AnakinSkywalker())));
        movies.add(new StarWarsMovie(7, "The Force Awakens", LocalDate.of(2015, 1, 1),
                Arrays.asList(new HanSolo(), new Rey(), new KyloRen())));
        movies.add(new StarWarsMovie(8, "The Last Jedi", LocalDate.of(2017, 1, 1),
                Arrays.asList(new Rey(), new KyloRen(), new LukeSkywalker())));
        movies.add(new StarWarsMovie(9, "The Rise of Skywalker", LocalDate.of(2019, 1, 1),
                Arrays.asList(new Rey(), new KyloRen(), new LukeSkywalker())));

    }
}
















