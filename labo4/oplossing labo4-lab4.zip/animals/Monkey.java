package animals;

import java.time.LocalDate;

public class Monkey extends Animal implements WildAnimal {
    private static final String SOUND = "CHATTER";

    public Monkey(String name, LocalDate dateOfBirth, Gender gender) {
        super(name, dateOfBirth, gender);
    }

    public void makeSound() {
        System.out.println(SOUND);
    }

    @Override
    public boolean endangered() {
        return true;
    }

    @Override
    public String toString() {
        return "Monkey{" +
                "endangered=" + endangered() +
                ", name='" + getName() + '\'' +
                ", dateOfBirth=" + getDateOfBirth() +
                ", gender=" + getGender() +
                '}';
    }
}
