package animals;

import java.time.LocalDate;

public class Lion extends Animal implements WildAnimal, FourLeggedAnimal {
    private static final String SOUND = "ROAR";

    public Lion(String name, LocalDate dateOfBirth, Gender gender) {
        super(name, dateOfBirth, gender);
    }

    public void makeSound() {
        System.out.println(SOUND);
    }

    @Override
    public boolean endangered() {
        return true;
    }

    @Override
    public String toString() {
        return "Lion{" +
                "endangered=" + endangered() +
                ", name='" + getName() + '\'' +
                ", dateOfBirth=" + getDateOfBirth() +
                ", gender=" + getGender() +
                '}';
    }
}
