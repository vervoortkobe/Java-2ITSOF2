package animals;

import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.function.Predicate;

public class Cage<T extends Animal> {
    private final int maxAnimals;
    private final SortedSet<T> animals = new TreeSet<>(new SortOnDateOfBirth());

    public Cage(int maxAnimals) {
        this.maxAnimals = maxAnimals;
    }

    public boolean addAnimal(T animal) {
        if (animals.size() >= maxAnimals) {
            return false;
        } else {
            animals.add(animal);
            return true;
        }
    }

    public void showAnimals() {
        for (T animal : animals) {
            System.out.println(animal.toString());
        }
    }

    public T removeOldestAnimal() {
        T animal = animals.first();
        animals.remove(animal);
        return animal;
    }

    public T getAnimal(Predicate<T> filter, Comparator<T> comparator) {
        return animals.stream()
                .filter(filter)
                .sorted(comparator)
                .findFirst()
                .orElse(null);
    }
}
