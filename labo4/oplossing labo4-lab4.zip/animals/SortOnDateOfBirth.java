package animals;

import java.util.Comparator;

public class SortOnDateOfBirth implements Comparator<Animal> {
    @Override
    public int compare(Animal o1, Animal o2) {
        return o1.getDateOfBirth().compareTo(o2.getDateOfBirth()); //oudste eerst
    }
}
