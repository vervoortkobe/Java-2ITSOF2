package animals;

import java.time.LocalDate;

public class Hippo extends Animal {
    private static final String SOUND = "HONK";

    public Hippo(String name, LocalDate dateOfBirth, Gender gender) {
        super(name, dateOfBirth, gender);
    }

    @Override
    public void makeSound() {
        System.out.println(SOUND);
    }
}
