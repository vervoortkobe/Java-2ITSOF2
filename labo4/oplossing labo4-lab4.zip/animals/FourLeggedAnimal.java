package animals;

public interface FourLeggedAnimal {
}
