package animals;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.function.Predicate;

public class Main {

    public static void main(String[] args) {
        Cage<Cat> catCage = new Cage<>(5);
        catCage.addAnimal(new Cat("Pluisje", CatBreed.BENGAL, LocalDate.of(2016, 5, 12), Gender.FEMALE));
        catCage.addAnimal(new Cat("Panter", CatBreed.SIAMESE, LocalDate.of(2014, 4, 28), Gender.MALE));
        catCage.addAnimal(new Cat("Garfield", CatBreed.RAGDOLL, LocalDate.of(2017, 8, 2), Gender.MALE));
        catCage.addAnimal(new Cat("Bolleke", CatBreed.RAGDOLL, LocalDate.of(2016, 10, 8), Gender.FEMALE));

        catCage.showAnimals();

        System.out.println("************************");
        Predicate<Cat> filterMale = cat -> cat.getGender() == Gender.MALE;
        Comparator<Cat> sortOnAge = (o1, o2) -> Integer.compare(o2.getDateOfBirth().getYear(), o1.getDateOfBirth().getYear());
        Predicate<Cat> filterNeuteredFemale = cat -> cat.getGender() == Gender.FEMALE_NEUTERED;

        System.out.println(catCage.getAnimal(filterMale, sortOnAge));
        System.out.println(catCage.getAnimal(filterNeuteredFemale, Comparator.naturalOrder()));
    }
}
