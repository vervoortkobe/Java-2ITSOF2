package zoo;

public class CareTaker {
    private final String name;
    private final Bonobo bonobo;

    public CareTaker(String name, Bonobo bonobo) {
        this.name = name;
        this.bonobo = bonobo;
    }

    public String getName() {
        return name;
    }

    public Bonobo getBonobo() {
        return bonobo;
    }

    @Override
    public String toString() {
        return "CareTaker{" +
                "name='" + name + '\'' +
                ", bonobo=" + bonobo +
                '}';
    }
}
