package zoo;

public class CareTakerFactory {

    public static CareTaker assignCareTaker(Bonobo bonobo) {
        if (bonobo.getDateOfBirth().getYear() < 2000) {
            return new CareTaker("Hans", bonobo);
        } else {
            return new CareTaker("Erik", bonobo);
        }
    }
}
